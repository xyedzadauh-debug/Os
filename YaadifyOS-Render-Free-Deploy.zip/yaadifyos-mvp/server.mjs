import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(ROOT, 'public');
const DATA = process.env.DATA_DIR || path.join(ROOT, 'data');
const UPLOADS = process.env.UPLOAD_DIR || path.join(ROOT, 'uploads');
fs.mkdirSync(DATA, { recursive: true });
fs.mkdirSync(UPLOADS, { recursive: true });
// Ensure the seeded private sample gallery exists even when UPLOAD_DIR is customized.
const bundledGallery = path.join(ROOT, 'uploads', 'demo-gallery.svg');
const sampleGallery = path.join(UPLOADS, 'demo-gallery.svg');
if (fs.existsSync(bundledGallery) && !fs.existsSync(sampleGallery)) fs.copyFileSync(bundledGallery, sampleGallery);
const db = new DatabaseSync(path.join(DATA, 'yaadifyos.sqlite'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=3000;');
const PORT = Number(process.env.PORT || 4173);
const DEMO = process.env.DEMO_MODE !== '0';
const SESSION_AGE = 14 * 24 * 60 * 60 * 1000;
const MAX_UPLOAD = 6 * 1024 * 1024;
const CURRENCY = { SAR: 1, AED: 0.98, USD: 0.27 }; // illustrative, NOT live FX

const events = [
  ['gitex-2026', 'GITEX Global 2026', 'Dubai', 'UAE', '2026-12-07', '2026-12-11', 'Dubai', 'Technology', 'The region’s ambitious technology showcase and a magnet for founders, brands and global teams.', 'photo-1540575467063-178a50c2df87', 1],
  ['black-hat-mea-2026', 'Black Hat MEA', 'Riyadh', 'Saudi Arabia', '2026-12-01', '2026-12-03', 'Riyadh', 'Cybersecurity', 'Security leaders, visionary exhibitors and a huge stage for memorable brand stories.', 'photo-1505373877841-8d25f7d46678', 1],
  ['leap-2027', 'LEAP 2027', 'Riyadh', 'Saudi Arabia', '2027-04-12', '2027-04-15', 'Riyadh', 'Technology', 'Meet the people and companies shaping what happens next in technology.', 'photo-1511578314322-379afb476865', 1],
  ['dubai-ai-week', 'Dubai AI Week', 'Dubai', 'UAE', '2027-02-16', '2027-02-18', 'Dubai', 'AI & Innovation', 'A destination for conversations, launches and connections around AI.', 'photo-1591115765373-5207764f72e7', 0],
  ['hospitality-future', 'Future Hospitality Forum', 'Riyadh', 'Saudi Arabia', '2027-05-04', '2027-05-06', 'Riyadh', 'Hospitality', 'Hospitality, tourism and investment, all connected in one place.', 'photo-1492684223066-81342ee5ff30', 0],
  ['design-week', 'Dubai Design Week', 'Dubai', 'UAE', '2027-11-09', '2027-11-13', 'Dubai', 'Design', 'Creative stories, inspiring installations and new perspectives.', 'photo-1517457373958-b7bdd4587205', 0],
];
const services = [
  ['Event Photographer', 'media', 'Photography', 'Professional exhibition photography with fast-turnaround edits.', 320, 1200, 2200, 'photo-1542038784456-1ea8e935640e', 'Fast delivery · Edited gallery', 'camera'],
  ['Event Videographer', 'media', 'Videography', 'Cinematic event coverage, interviews and a polished highlight edit.', 450, 1800, 3200, 'photo-1492619375914-88005aa9e8fb', '4K capture · Highlight reel', 'video'],
  ['Same-Day Social Reels', 'media', 'Content creation', 'Vertical reels edited for posting during your exhibition day.', 400, 1500, 2750, 'photo-1536240478700-b869070f9279', '9:16 format · Same-day', 'clapperboard'],
  ['Speaker Clip Editing', 'media', 'AI-powered clips', 'Turn speaker footage into short, captioned and shareable clips (demo intake).', 200, 750, 1300, 'photo-1475721027785-f74eccf877e2', 'Captions · Multi-format', 'sparkles'],
  ['Interview Crew & Setup', 'media', 'Interviews', 'Book a dedicated interview camera and lighting setup.', 550, 2100, 3900, 'photo-1574717024653-61fd2cf4d44d', 'Audio · Lights · Operator', 'mic'],
  ['Exhibition Booth Host', 'crew', 'Event crew', 'Experienced multilingual brand representatives for busy expo days.', 130, 480, 850, 'photo-1521737711867-e3b97375f902', 'Vetted talent · Briefing', 'users'],
  ['AV / Stage Technician', 'crew', 'Technical crew', 'On-site technician for audio, screens, cues and show operations.', 180, 680, 1250, 'photo-1493225457124-a3eb161ffa5f', 'Setup · Live operation', 'headphones'],
  ['Event Production Assistant', 'crew', 'Event crew', 'Reliable extra hands for a smooth day of event delivery.', 110, 400, 740, 'photo-1552664730-d307ca884978', 'On-site · Flexible', 'briefcase'],
  ['UGC Content Creator', 'creator', 'Creators', 'Authentic short-form content from experienced event creators.', 300, 1100, 2100, 'photo-1611162616475-46b635cb6868', 'UGC · Social-ready', 'smartphone'],
  ['Influencer Walkthrough', 'creator', 'Creators', 'An on-camera exhibition walkthrough with a regional creator.', 750, 2800, 5000, 'photo-1516321318423-f06f85e504b3', 'Brief approval · Licensing', 'star'],
  ['Meeting Room Booking', 'city', 'Business travel', 'A practical meeting room for your visiting team and clients.', 180, 650, 1200, 'photo-1497366754035-f200968a6e72', 'Wi-Fi · Meeting-ready', 'building'],
  ['VIP City Concierge', 'city', 'Concierge', 'Local support for transfers, meetings and event-day arrangements.', 250, 940, 1750, 'photo-1486406146926-c627a92ad1ab', 'City support · VIP', 'map-pin'],
  ['Business Dinner Planning', 'connect', 'Networking', 'Curated restaurant and private table coordination for your team.', 220, 850, 1550, 'photo-1517248135467-4c7edcad34c4', 'Restaurant matching · Coordination', 'utensils'],
  ['Sponsor Media Tracker', 'media', 'Reporting', 'Organize sponsor deliverables and track coverage fulfillment.', 260, 980, 1800, 'photo-1460925895917-afdab827c52f', 'Deliverable board · Reports', 'chart'],
];
function passwordHash(p, salt = crypto.randomBytes(16).toString('hex')) {
  return `${salt}:${crypto.scryptSync(p, salt, 64).toString('hex')}`;
}
function passwordVerify(p, stored) {
  const [salt, expected] = stored.split(':');
  const candidate = crypto.scryptSync(p, salt, 64);
  const expectedBuf = Buffer.from(expected, 'hex');
  return candidate.length === expectedBuf.length && crypto.timingSafeEqual(candidate, expectedBuf);
}
function initDB() {
  db.exec(`
  CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, role TEXT NOT NULL CHECK(role IN ('customer','exhibitor','supplier','organizer','admin')), password_hash TEXT NOT NULL, company TEXT DEFAULT '', created_at TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), expires_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, name TEXT, city TEXT, country TEXT, starts_on TEXT, ends_on TEXT, venue TEXT, category TEXT, description TEXT, image_key TEXT, featured INTEGER DEFAULT 0);
  CREATE TABLE IF NOT EXISTS services (id INTEGER PRIMARY KEY, title TEXT, module TEXT, category TEXT, description TEXT, hourly_sar INTEGER, halfday_sar INTEGER, fullday_sar INTEGER, image_key TEXT, inclusions TEXT, icon TEXT, supplier_id INTEGER REFERENCES users(id));
  CREATE TABLE IF NOT EXISTS bookings (id INTEGER PRIMARY KEY, reference TEXT UNIQUE, user_id INTEGER NOT NULL REFERENCES users(id), service_id INTEGER NOT NULL REFERENCES services(id), event_id INTEGER NOT NULL REFERENCES events(id), supplier_id INTEGER REFERENCES users(id), service_date TEXT NOT NULL, start_time TEXT NOT NULL, duration TEXT NOT NULL, units INTEGER NOT NULL, price_sar INTEGER NOT NULL, currency TEXT NOT NULL, total_display REAL NOT NULL, status TEXT NOT NULL, notes TEXT DEFAULT '', created_at TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS media (id INTEGER PRIMARY KEY, booking_id INTEGER NOT NULL REFERENCES bookings(id), uploader_id INTEGER REFERENCES users(id), title TEXT, file_name TEXT, storage_name TEXT, mime TEXT, size INTEGER, approved INTEGER DEFAULT 0, created_at TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS supplier_profiles (user_id INTEGER PRIMARY KEY REFERENCES users(id), speciality TEXT, bio TEXT, city TEXT, available INTEGER DEFAULT 1, rating REAL DEFAULT 4.9);
  CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY, actor_id INTEGER, action TEXT, entity_id TEXT, created_at TEXT);
  CREATE INDEX IF NOT EXISTS idx_bookings_user ON bookings(user_id);
  CREATE INDEX IF NOT EXISTS idx_bookings_supplier ON bookings(supplier_id);
  CREATE INDEX IF NOT EXISTS idx_bookings_slot ON bookings(service_id,service_date,start_time);
  CREATE INDEX IF NOT EXISTS idx_media_booking ON media(booking_id);
  `);
  if (db.prepare('SELECT COUNT(*) c FROM users').get().c) return;
  const now = new Date().toISOString();
  const users = [
    ['Alex Morgan', 'customer@yaadifyos.demo', 'customer', 'Freelance creative'],
    ['Riya Sharma', 'exhibitor@yaadifyos.demo', 'exhibitor', 'Northstar Technologies'],
    ['Studio Collective', 'supplier@yaadifyos.demo', 'supplier', 'Studio Collective'],
    ['Event Operations', 'organizer@yaadifyos.demo', 'organizer', 'Expo Organizers'],
    ['YaadifyOS Admin', 'admin@yaadifyos.demo', 'admin', 'Yaadify / Yaadgaar MediaTech'],
    ['Creative Motion', 'motion@yaadifyos.demo', 'supplier', 'Creative Motion'],
  ];
  const insertU = db.prepare('INSERT INTO users(name,email,role,password_hash,company,created_at) VALUES(?,?,?,?,?,?)');
  for (const u of users) insertU.run(u[0], u[1], u[2], passwordHash('Demo123!'), u[3], now);
  const insertE = db.prepare('INSERT INTO events(slug,name,city,country,starts_on,ends_on,venue,category,description,image_key,featured) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
  for (const e of events) insertE.run(...e);
  const insertS = db.prepare('INSERT INTO services(title,module,category,description,hourly_sar,halfday_sar,fullday_sar,image_key,inclusions,icon,supplier_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
  services.forEach((s, i) => insertS.run(...s, [1, 3, 4, 7, 8, 10, 11, 12].includes(i) ? 6 : 3));
  db.prepare('INSERT INTO supplier_profiles(user_id,speciality,bio,city,available,rating) VALUES(?,?,?,?,?,?)').run(3, 'Photography · Event crew', 'A curated crew for exhibition floors and stages.', 'Riyadh', 1, 4.9);
  db.prepare('INSERT INTO supplier_profiles(user_id,speciality,bio,city,available,rating) VALUES(?,?,?,?,?,?)').run(6, 'Videography · Production', 'Commercial video and on-site content production.', 'Dubai', 1, 4.8);
  db.prepare('INSERT INTO bookings(reference,user_id,service_id,event_id,supplier_id,service_date,start_time,duration,units,price_sar,currency,total_display,status,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run('YOS-10001', 1, 1, 1, 3, '2026-12-08', '10:00', 'half', 1, 1200, 'SAR', 1200, 'confirmed', 'Demo booking — North Hall booth coverage', now);
  db.prepare('INSERT INTO bookings(reference,user_id,service_id,event_id,supplier_id,service_date,start_time,duration,units,price_sar,currency,total_display,status,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run('YOS-10002', 2, 2, 3, 3, '2027-04-13', '09:00', 'full', 1, 3200, 'SAR', 3200, 'pending', 'Demo booking — keynote highlights', now);
  db.prepare('INSERT INTO media(booking_id,uploader_id,title,file_name,storage_name,mime,size,approved,created_at) VALUES(?,?,?,?,?,?,?,?,?)').run(1, 3, 'GITEX booth highlights · Preview', 'demo-gallery.svg', 'demo-gallery.svg', 'image/svg+xml', fs.statSync(sampleGallery).size, 1, now);
}
initDB();

const columnEvent = 'id,slug,name,city,country,starts_on,ends_on,venue,category,description,image_key,featured';
const columnService = 'id,title,module,category,description,hourly_sar,halfday_sar,fullday_sar,image_key,inclusions,icon,supplier_id';
const publicUser = (u) => u ? { id: u.id, name: u.name, email: u.email, role: u.role, company: u.company } : null;
const json = (res, status, obj, headers = {}) => {
  const b = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(b), 'Cache-Control': 'no-store', ...headers }); res.end(b);
};
const fail = (res, status, message) => json(res, status, { error: message });
const audit = (actor, action, entity) => db.prepare('INSERT INTO audit_log(actor_id,action,entity_id,created_at) VALUES(?,?,?,?)').run(actor, action, String(entity), new Date().toISOString());
const getCookies = req => Object.fromEntries((req.headers.cookie || '').split(';').map(v => v.trim().split('=')).filter(v => v.length === 2));
const userFromReq = req => {
  const token = getCookies(req).yos_session;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  return db.prepare('SELECT u.* FROM users u JOIN sessions s ON s.user_id=u.id WHERE s.token_hash=? AND s.expires_at>?').get(crypto.createHash('sha256').update(token).digest('hex'), Date.now()) || null;
};
function newSession(res, user) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').run(crypto.createHash('sha256').update(token).digest('hex'), user.id, Date.now() + SESSION_AGE);
  const secure = process.env.COOKIE_SECURE === '1' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `yos_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_AGE / 1000}${secure}`);
}
function requireRole(res, user, roles) { if (!user) { fail(res, 401, 'Please sign in first.'); return false; } if (!roles.includes(user.role)) { fail(res, 403, 'Not authorized for this action.'); return false; } return true; }
async function readJSON(req, maxSize = 800000) {
  let chunks = [], size = 0;
  for await (const c of req) { size += c.length; if (size > maxSize) throw Object.assign(new Error('Request too large'), {status: 413}); chunks.push(c); }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); } catch { throw Object.assign(new Error('Invalid JSON body'), {status: 400}); }
}
function validateBooking(b) {
  const service = db.prepare(`SELECT ${columnService} FROM services WHERE id=?`).get(Number(b.serviceId));
  const event = db.prepare(`SELECT ${columnEvent} FROM events WHERE id=?`).get(Number(b.eventId));
  if (!service || !event) throw Object.assign(new Error('Invalid event or service.'), {status: 400});
  const date = String(b.date || ''); const start = String(b.time || '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(Date.parse(date))) throw Object.assign(new Error('Select a valid date.'), {status: 400});
  if (date < event.starts_on || date > event.ends_on) throw Object.assign(new Error('Date must be within the selected event.'), {status: 400});
  if (date < new Date().toISOString().slice(0, 10)) throw Object.assign(new Error('Cannot book in the past.'), {status: 400});
  if (!/^([01]\d|2[0-3]):(00|30)$/.test(start)) throw Object.assign(new Error('Select a valid start time.'), {status: 400});
  const duration = String(b.duration || '');
  if (!['hour', 'half', 'full'].includes(duration)) throw Object.assign(new Error('Invalid duration.'), {status: 400});
  const units = Number(b.units || 1);
  if (!Number.isSafeInteger(units) || units < 1 || units > 10) throw Object.assign(new Error('Quantity must be 1–10.'), {status: 400});
  const hours = { hour: 1, half: 4, full: 8 }[duration];
  const minutes = Number(start.slice(0, 2)) * 60 + Number(start.slice(3));
  if (minutes < 7 * 60 || minutes + hours * 60 > 23 * 60) throw Object.assign(new Error('Select a start time between 07:00 and the latest possible end time (23:00).'), {status: 400});
  const price_sar = (duration === 'hour' ? service.hourly_sar : duration === 'half' ? service.halfday_sar : service.fullday_sar) * units;
  const overlapping = db.prepare(`SELECT b.id FROM bookings b WHERE b.service_id=? AND b.event_id=? AND b.service_date=? AND b.status NOT IN ('cancelled','rejected') AND (? < (CAST(substr(b.start_time,1,2) AS INTEGER)*60 + CAST(substr(b.start_time,4,2) AS INTEGER) + CASE b.duration WHEN 'hour' THEN 60 WHEN 'half' THEN 240 ELSE 480 END)) AND ((? + ?) > (CAST(substr(b.start_time,1,2) AS INTEGER)*60 + CAST(substr(b.start_time,4,2) AS INTEGER))) LIMIT 1`).get(service.id, event.id, date, minutes, minutes, hours*60);
  if (overlapping) throw Object.assign(new Error(`That service already has a booking overlapping ${start}. Try another time.`), {status: 409});
  return { service, event, date, start, duration, units, price_sar, notes: String(b.notes || '').slice(0, 400) };
}
const bookingQuery = `SELECT b.*,s.title service_title,s.module service_module,s.image_key service_image,e.name event_name,e.city event_city,u.name customer_name FROM bookings b JOIN services s ON b.service_id=s.id JOIN events e ON b.event_id=e.id JOIN users u ON b.user_id=u.id`;
function listBookings(user) {
  if (user.role === 'admin' || user.role === 'organizer') return db.prepare(`${bookingQuery} ORDER BY b.created_at DESC`).all();
  if (user.role === 'supplier') return db.prepare(`${bookingQuery} WHERE b.supplier_id=? ORDER BY b.created_at DESC`).all(user.id);
  return db.prepare(`${bookingQuery} WHERE b.user_id=? ORDER BY b.created_at DESC`).all(user.id);
}
function visibleMedia(user) {
  const query = `SELECT m.*,b.reference,b.user_id,b.supplier_id,e.name event_name,s.title service_title,u.name uploader_name FROM media m JOIN bookings b ON m.booking_id=b.id JOIN events e ON b.event_id=e.id JOIN services s ON b.service_id=s.id LEFT JOIN users u ON m.uploader_id=u.id`;
  if (user.role === 'admin' || user.role === 'organizer') return db.prepare(`${query} ORDER BY m.id DESC`).all();
  if (user.role === 'supplier') return db.prepare(`${query} WHERE b.supplier_id=? ORDER BY m.id DESC`).all(user.id);
  return db.prepare(`${query} WHERE b.user_id=? AND m.approved=1 ORDER BY m.id DESC`).all(user.id);
}
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.webmanifest': 'application/manifest+json', '.json': 'application/json; charset=utf-8', '.ico': 'image/x-icon', '.woff2': 'font/woff2' };
function serveStatic(res, pathname, method) {
  const requested = pathname === '/' || !path.extname(pathname) ? '/index.html' : pathname;
  const target = path.resolve(PUBLIC, '.' + decodeURIComponent(requested));
  if (target !== PUBLIC && !target.startsWith(PUBLIC + path.sep)) return fail(res, 403, 'Forbidden.');
  if (!fs.existsSync(target) || !fs.statSync(target).isFile()) return fail(res, 404, 'Not found.');
  const type = MIME[path.extname(target)] || 'application/octet-stream';
  res.writeHead(200, { 'Content-Type': type, 'Cache-Control': path.basename(target) === 'index.html' || path.basename(target) === 'sw.js' ? 'no-cache' : 'public, max-age=3600', 'X-Content-Type-Options': 'nosniff' });
  if (method === 'HEAD') return res.end();
  fs.createReadStream(target).pipe(res);
}
async function api(req, res, pathname, url) {
  const method = req.method; const user = userFromReq(req);
  if (method === 'GET' && pathname === '/api/health') return json(res, 200, { ok: true, app: 'YaadifyOS', demo: DEMO, database: 'SQLite', version: '0.1.0' });
  if (method === 'GET' && pathname === '/api/bootstrap') return json(res, 200, { events: db.prepare(`SELECT ${columnEvent} FROM events ORDER BY starts_on`).all(), services: db.prepare(`SELECT ${columnService} FROM services`).all(), user: publicUser(user), currencies: CURRENCY, demo: DEMO, version: '0.1.0' });
  if (method === 'GET' && pathname === '/api/session') return json(res, 200, { user: publicUser(user) });
  if (method === 'POST' && pathname === '/api/auth/login') {
    const b = await readJSON(req); const u = db.prepare('SELECT * FROM users WHERE lower(email)=lower(?)').get(String(b.email || '').trim());
    if (!u || !passwordVerify(String(b.password || ''), u.password_hash)) return fail(res, 401, 'Invalid email or password.');
    newSession(res, u); audit(u.id, 'session.login', u.id); return json(res, 200, { user: publicUser(u) });
  }
  if (method === 'POST' && pathname === '/api/auth/demo') {
    if (!DEMO) return fail(res, 404, 'Demo mode disabled.');
    const b = await readJSON(req); const role = String(b.role || 'customer');
    if (!['customer','exhibitor','supplier','organizer','admin'].includes(role)) return fail(res, 400, 'Unknown demo role.');
    const u = db.prepare('SELECT * FROM users WHERE role=? ORDER BY id LIMIT 1').get(role);
    newSession(res, u); audit(u.id, 'session.demo', u.id); return json(res, 200, { user: publicUser(u) });
  }
  if (method === 'POST' && pathname === '/api/auth/logout') {
    const token = getCookies(req).yos_session;
    if (token) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(crypto.createHash('sha256').update(token).digest('hex'));
    res.setHeader('Set-Cookie', 'yos_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'); return json(res, 200, { ok: true });
  }
  if (method === 'GET' && pathname === '/api/events') {
    const q = (url.searchParams.get('q') || '').trim().toLowerCase(); const city = url.searchParams.get('city') || '';
    return json(res, 200, { events: db.prepare(`SELECT ${columnEvent} FROM events WHERE (lower(name) LIKE ? OR lower(category) LIKE ? OR lower(city) LIKE ?) AND (?='' OR city=?) ORDER BY starts_on`).all(...Array(3).fill('%' + q + '%'), city, city) });
  }
  if (method === 'GET' && pathname === '/api/services') {
    const module = url.searchParams.get('module') || '';
    return json(res, 200, { services: db.prepare(`SELECT ${columnService} FROM services WHERE (?='' OR module=?)`).all(module, module) });
  }
  if (method === 'POST' && pathname === '/api/checkout') {
    if (!requireRole(res, user, ['customer','exhibitor','admin'])) return;
    const b = await readJSON(req); const items = b.items;
    if (!Array.isArray(items) || !items.length || items.length > 12) return fail(res, 400, 'Cart must have 1–12 items.');
    const currency = String(b.currency || 'SAR').toUpperCase(); if (!CURRENCY[currency]) return fail(res, 400, 'Invalid currency.');
    const completed = [];
    try {
      db.exec('BEGIN IMMEDIATE');
      const insert = db.prepare('INSERT INTO bookings(reference,user_id,service_id,event_id,supplier_id,service_date,start_time,duration,units,price_sar,currency,total_display,status,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
      for (const item of items) {
        const v = validateBooking(item);
        const reference = `YOS-${crypto.randomInt(100000,999999)}`;
        const priceDisplay = Number((v.price_sar * CURRENCY[currency]).toFixed(2));
        const created = new Date().toISOString();
        const result = insert.run(reference, user.id, v.service.id, v.event.id, v.service.supplier_id, v.date, v.start, v.duration, v.units, v.price_sar, currency, priceDisplay, 'pending', v.notes, created);
        completed.push({ id: Number(result.lastInsertRowid), reference, service_title: v.service.title, event_name: v.event.name, price_sar: v.price_sar, total_display: priceDisplay, currency });
        audit(user.id, 'booking.created', reference);
      }
      db.exec('COMMIT');
      return json(res, 201, { bookings: completed, payment: 'No payment processed — demo booking request only.', status: 'pending' });
    } catch (err) { db.exec('ROLLBACK'); throw err; }
  }
  if (method === 'GET' && pathname === '/api/bookings') {
    if (!requireRole(res, user, ['customer','exhibitor','supplier','organizer','admin'])) return;
    return json(res, 200, { bookings: listBookings(user) });
  }
  const bookingStatus = pathname.match(/^\/api\/bookings\/(\d+)\/status$/);
  if (method === 'PATCH' && bookingStatus) {
    if (!requireRole(res, user, ['supplier','organizer','admin'])) return;
    const b = await readJSON(req); const status = String(b.status || '');
    if (!['pending','confirmed','completed','rejected'].includes(status)) return fail(res, 400, 'Invalid booking status.');
    const booking = db.prepare('SELECT * FROM bookings WHERE id=?').get(Number(bookingStatus[1]));
    if (!booking || (user.role === 'supplier' && booking.supplier_id !== user.id)) return fail(res, 404, 'Booking not found.');
    if (booking.status === 'cancelled') return fail(res, 409, 'Cancelled booking cannot be changed.');
    db.prepare('UPDATE bookings SET status=? WHERE id=?').run(status, booking.id); audit(user.id, 'booking.status', booking.id); return json(res, 200, { ok: true, status });
  }
  const bookingCancel = pathname.match(/^\/api\/bookings\/(\d+)\/cancel$/);
  if (method === 'POST' && bookingCancel) {
    if (!requireRole(res, user, ['customer','exhibitor','admin'])) return;
    const booking = db.prepare('SELECT * FROM bookings WHERE id=?').get(Number(bookingCancel[1]));
    if (!booking || (user.role !== 'admin' && booking.user_id !== user.id)) return fail(res, 404, 'Booking not found.');
    if (!['pending','confirmed'].includes(booking.status)) return fail(res, 409, 'Booking cannot be cancelled.');
    db.prepare('UPDATE bookings SET status=? WHERE id=?').run('cancelled', booking.id); audit(user.id, 'booking.cancelled', booking.id); return json(res, 200, { ok: true });
  }
  if (method === 'GET' && pathname === '/api/dashboard') {
    if (!requireRole(res, user, ['customer','exhibitor','supplier','organizer','admin'])) return;
    const bookings = listBookings(user);
    const media = visibleMedia(user);
    const totals = { bookings: bookings.length, active: bookings.filter(b => ['pending','confirmed'].includes(b.status)).length, delivered: bookings.filter(b => b.status === 'completed').length, media: media.length, bookedValueSAR: bookings.filter(b => b.status !== 'cancelled').reduce((a,b) => a + b.price_sar,0), suppliers: db.prepare("SELECT COUNT(*) c FROM users WHERE role='supplier'").get().c, events: db.prepare('SELECT COUNT(*) c FROM events').get().c };
    return json(res, 200, { totals, bookings: bookings.slice(0, 8), media: media.slice(0, 4) });
  }
  if (method === 'GET' && pathname === '/api/suppliers') {
    const suppliers = db.prepare("SELECT u.id,u.name,u.company,p.speciality,p.bio,p.city,p.available,p.rating FROM users u JOIN supplier_profiles p ON u.id=p.user_id ORDER BY p.rating DESC").all();
    return json(res, 200, { suppliers });
  }
  if (method === 'PATCH' && pathname === '/api/supplier/availability') {
    if (!requireRole(res, user, ['supplier'])) return;
    const b = await readJSON(req);
    db.prepare('UPDATE supplier_profiles SET available=? WHERE user_id=?').run(b.available ? 1 : 0, user.id); audit(user.id, 'supplier.availability', user.id); return json(res, 200, { ok: true, available: !!b.available });
  }
  if (method === 'GET' && pathname === '/api/media') {
    if (!requireRole(res, user, ['customer','exhibitor','supplier','organizer','admin'])) return;
    return json(res, 200, { media: visibleMedia(user) });
  }
  if (method === 'POST' && pathname === '/api/media') {
    if (!requireRole(res, user, ['supplier','organizer','admin','customer','exhibitor'])) return;
    const b = await readJSON(req, MAX_UPLOAD * 1.5);
    const booking = db.prepare('SELECT * FROM bookings WHERE id=?').get(Number(b.bookingId));
    if (!booking) return fail(res, 404, 'Booking not found.');
    const allowed = ['admin','organizer'].includes(user.role) || booking.user_id === user.id || (user.role === 'supplier' && booking.supplier_id === user.id);
    if (!allowed) return fail(res, 403, 'Not authorized to upload to this booking.');
    const mime = String(b.mime || ''); const match = /^data:(image\/jpeg|image\/png|image\/webp|application\/pdf);base64,([A-Za-z0-9+/=]+)$/.exec(String(b.data || ''));
    if (!match || match[1] !== mime) return fail(res, 400, 'Only JPG, PNG, WebP and PDF files are supported in the demo.');
    const content = Buffer.from(match[2], 'base64');
    if (!content.length || content.length > MAX_UPLOAD) return fail(res, 413, 'File must be under 6 MB.');
    const signatures = { 'image/jpeg': [0xff,0xd8,0xff], 'image/png':[0x89,0x50,0x4e,0x47], 'image/webp':[0x52,0x49,0x46,0x46], 'application/pdf':[0x25,0x50,0x44,0x46] };
    if (!signatures[mime].every((x,i) => content[i] === x) || (mime === 'image/webp' && content.toString('ascii',8,12) !== 'WEBP')) return fail(res, 400, 'File content did not match its type.');
    const extension = { 'image/jpeg':'.jpg', 'image/png':'.png', 'image/webp':'.webp', 'application/pdf':'.pdf' }[mime];
    const storageName = crypto.randomUUID() + extension;
    fs.writeFileSync(path.join(UPLOADS, storageName), content, { flag: 'wx', mode: 0o600 });
    const title = String(b.title || 'Uploaded media').slice(0, 100); const fileName = path.basename(String(b.fileName || 'upload' + extension)).slice(0, 120);
    const approved = ['supplier','admin','organizer'].includes(user.role) ? 1 : 0;
    const insert = db.prepare('INSERT INTO media(booking_id,uploader_id,title,file_name,storage_name,mime,size,approved,created_at) VALUES(?,?,?,?,?,?,?,?,?)').run(booking.id,user.id,title,fileName,storageName,mime,content.length,approved,new Date().toISOString());
    audit(user.id, 'media.uploaded', insert.lastInsertRowid);
    return json(res, 201, { id: Number(insert.lastInsertRowid), approved: !!approved, message: approved ? 'Media uploaded.' : 'Submitted for approval.' });
  }
  const mediaApproval = pathname.match(/^\/api\/media\/(\d+)\/approval$/);
  if (method === 'PATCH' && mediaApproval) {
    if (!requireRole(res, user, ['admin','organizer'])) return;
    const b = await readJSON(req);
    const result = db.prepare('UPDATE media SET approved=? WHERE id=?').run(b.approved ? 1 : 0, Number(mediaApproval[1]));
    if (!result.changes) return fail(res, 404, 'Media not found.');
    audit(user.id, 'media.approval', mediaApproval[1]); return json(res, 200, { ok: true });
  }
  const mediaFile = pathname.match(/^\/api\/media\/(\d+)\/file$/);
  if (method === 'GET' && mediaFile) {
    if (!requireRole(res, user, ['customer','exhibitor','supplier','organizer','admin'])) return;
    const item = db.prepare('SELECT m.*,b.user_id,b.supplier_id FROM media m JOIN bookings b ON m.booking_id=b.id WHERE m.id=?').get(Number(mediaFile[1]));
    if (!item || !(['admin','organizer'].includes(user.role) || (user.role === 'supplier' && item.supplier_id===user.id) || (item.user_id===user.id && item.approved))) return fail(res, 404, 'Media not found.');
    const target = path.join(UPLOADS,item.storage_name);
    if (!fs.existsSync(target)) return fail(res, 404, 'Media file missing.');
    const download = url.searchParams.has('download');
    res.writeHead(200, { 'Content-Type': item.mime, 'Content-Length': fs.statSync(target).size, 'Content-Disposition': `${download ? 'attachment' : 'inline'}; filename="${item.file_name.replace(/[^\w.\- ]/g, '_')}"`, 'Cache-Control':'private, no-store', 'X-Content-Type-Options':'nosniff', 'Content-Security-Policy':"sandbox" });
    return fs.createReadStream(target).pipe(res);
  }
  if (method === 'POST' && pathname === '/api/concierge/chat') {
    const b = await readJSON(req); const message = String(b.message || '').slice(0, 600).toLowerCase();
    const city = /dubai|gitex|uae/.test(message) ? 'Dubai' : /riyadh|leap|saudi/.test(message) ? 'Riyadh' : null;
    const module = /photo|camera/.test(message) ? 'media' : /video|reel|film|interview/.test(message) ? 'media' : /crew|staff|technician/.test(message) ? 'crew' : /hotel|transport|city|room|concierge/.test(message) ? 'city' : /dinner|network/.test(message) ? 'connect' : /creator|influencer|ugc/.test(message) ? 'creator' : 'media';
    const picks = db.prepare(`SELECT id,title,module,halfday_sar,image_key FROM services WHERE module=? ORDER BY id LIMIT 3`).all(module);
    const selectedEvent = db.prepare(`SELECT id,slug,name FROM events WHERE city=? ORDER BY starts_on LIMIT 1`).get(city || 'Riyadh');
    const answer = `I can help coordinate ${module === 'media' ? 'coverage and content production' : module === 'crew' ? 'on-site event teams' : module === 'city' ? 'city arrangements' : module === 'connect' ? 'business networking and dinner planning' : 'creator collaborations'}${city ? ` in ${city}` : ''}. Here are relevant demo services. Choose one to configure a booking. For live availability and quotations, a production integration is required.`;
    return json(res, 200, { reply: answer, services: picks, event: selectedEvent, mode: 'rules-based demo assistant — not an LLM or live inventory' });
  }
  return fail(res, 404, 'API route not found.');
}
const server = http.createServer(async (req, res) => {
  const host = req.headers.host || `localhost:${PORT}`;
  let url;
  try { url = new URL(req.url, `http://${host}`); } catch { return fail(res, 400, 'Invalid URL.'); }
  const pathname = url.pathname;
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' https://images.unsplash.com data: blob:; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; font-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  if (req.method === 'OPTIONS') return res.writeHead(204, {'Allow':'GET, HEAD, POST, PATCH, OPTIONS'}).end();
  if (['POST','PATCH','PUT','DELETE'].includes(req.method)) {
    const origin = req.headers.origin;
    if (origin && new URL(origin).host !== host) return fail(res, 403, 'Cross-origin write blocked.');
    const site = req.headers['sec-fetch-site'];
    if (site && !['same-origin','none'].includes(site)) return fail(res, 403, 'Cross-site write blocked.');
  }
  try {
    if (pathname.startsWith('/api/')) return await api(req,res,pathname,url);
    if (req.method === 'GET' || req.method === 'HEAD') return serveStatic(res,pathname,req.method);
    return fail(res,405,'Method not allowed.');
  } catch(err) {
    console.error('Request failed:', err.message);
    return fail(res, err.status || 500, err.status ? err.message : 'An unexpected error occurred.');
  }
});
server.listen(PORT, process.env.HOST || '127.0.0.1', () => console.log(`YaadifyOS running at http://localhost:${PORT} (${DEMO ? 'DEMO' : 'production config'})`));
