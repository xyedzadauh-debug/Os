# YaadifyOS — EventTech × MediaTech operating system

**Mobile-first Vue 3 progressive web app with a working persistent backend.**
Powered by Yaadify and Yaadgaar MediaTech.

> **MVP / demo environment, not a live booking platform.** Event schedules and prices are illustrative, no payments are processed, and the concierge is a rules-based helper rather than an AI service. The app implements working data-backed booking requests, role-specific workspaces, supplier availability, media upload and approval, and a local SQLite database.

## Start in 30 seconds

**Requirements:** Node.js **22.13+** (the MVP uses the `node:sqlite` built-in module). No `npm install`, bundler, Docker, PHP, or MySQL required.

```bash
# Extract the ZIP, then from the project directory:
node server.mjs
# or: npm start
```

Open **http://localhost:4173** in your browser. Open the same page on a phone when the server is hosted on an HTTPS domain or an accessible machine. To listen on your network, use `HOST=0.0.0.0 node server.mjs` and your computer's LAN IP address. Installable PWA and service worker require HTTPS or localhost (browsers generally do not permit installation on ordinary HTTP LAN hosts).

The SQLite database is automatically created and seeded in `data/yaadifyos.sqlite` on first start. Media uploads live in `uploads/`, outside the web root. Bookings, approvals, authentication sessions and supplier availability survive a server restart.

### Explore roles immediately

Use **Profile → Demo playground** or the sign-in sheet to switch roles with one tap.

| Portal | Demo account | Password |
|---|---|---|
| Customer | `customer@yaadifyos.demo` | `Demo123!` |
| Exhibitor | `exhibitor@yaadifyos.demo` | `Demo123!` |
| Supplier | `supplier@yaadifyos.demo` | `Demo123!` |
| Organizer | `organizer@yaadifyos.demo` | `Demo123!` |
| Super admin | `admin@yaadifyos.demo` | `Demo123!` |

**Never deploy the demo database or demo accounts in a real customer environment.** `DEMO_MODE=0` disables one-tap role switching, but does not replace demo accounts or complete the production security requirements.

## What is functional

| Area | Working in this MVP | Needs a production integration |
|---|---|---|
| Homepage and events | Responsive homepage, searchable event directory, city/category filters, event-specific marketplaces, deep links | Official live event dates, organizer partnerships |
| MediaOS | Photography/video bookings; hourly, half- and full-day pricing; private gallery; uploads, previews and downloads; moderation | Automated reels, speaker clipping, video transcoding, live event delivery, rights management, coverage reports |
| CrewOS | Crew service bookings; supplier profiles; availability toggle; assignments; accept/complete/reject actions | Real-time availability/inventory, crew payouts, supplier onboarding |
| CityOS | City discovery and bookable meeting-room/concierge services | Hotel, restaurant, transport and tour inventory/APIs; VIP concierge fulfillment |
| ConnectOS | Dinner-planning service booking, concierge recommendations | Matchmaking, event networking, table reservations, invitations |
| CreatorOS | Creator service listings and bookings; event asset upload and approval | Influencer discovery APIs, campaigns, UGC licensing and payouts |
| Checkout | Browser cart, server-side quote calculation, transactionally persisted booking requests, overlap prevention, cancellation | Payment processor, invoices, VAT, refund policy, availability holds |
| Dashboards | Customer/exhibitor bookings; supplier jobs; organizer/admin bookings and approvals; basic KPIs | Multi-tenancy, reporting warehouse, accounting, operations workflows |
| Concierge | Interactive keyword-based service suggestions | Production AI model, RAG, verified partner inventory |
| PWA | Manifest, icons, standalone display, basic service-worker caching, shell offline fallback, deep links, EN/AR and RTL, themes, locally triggered notification permission | Web Push subscription + VAPID backend, offline mutations, full Arabic translation review |

## Mobile-first experience

- Fixed five-item bottom navigation on phones: Home, Explore, Bookings, Media, Profile.
- Desktop sidebar with OS modules, workspaces and top search.
- Touch targets, safe-area insets, horizontal category scroll, full-screen booking steps, sheets for sign-in and upload.
- English/Arabic interface switching and RTL layout foundation. Core navigation and common booking labels are translated; **content and some management views remain English in this MVP**.
- Light/dark mode, selectable SAR/AED/USD **illustrative** conversion rates; not live FX.
- Hosted photos from Unsplash (online only), with a bundled SVG fallback for offline use. Review image usage/attribution before a commercial launch.

## Architecture

```
yaadifyos-mvp/
├── server.mjs                   # REST server, SQLite persistence, auth, role checks
├── package.json                 # zero-dependency run/test scripts
├── public/
│   ├── index.html               # app entrypoint + native mobile metadata
│   ├── app.js                   # Vue 3 app, OS modules and route-driven views
│   ├── styles.css               # mobile-first design system
│   ├── sw.js                    # offline app-shell + push event hook
│   ├── manifest.webmanifest     # installable PWA configuration
│   └── assets/                  # vendored Vue runtime, icons, SVG fallback
├── uploads/                     # private upload storage, never publicly served
├── data/                        # persisted SQLite (created on first start)
├── tests/integration.test.mjs   # real API tests with temporary database
├── docs/openapi.yaml            # API contract
├── docs/mysql-schema.sql        # MySQL transition reference (NOT deployed)
└── docs/architecture.md         # production integration and security roadmap
```

**Frontend:** Vue 3.5 (MIT-licensed, locally bundled, without compilation). Shared `event-card`, `service-card`, `metric-card`, `booking-row`, `app-icon` components. Client-side history routes with native server deep-link fallback. UI and state live in `public/app.js`; this deliberate zero-build layout makes the demo runnable in a restricted environment, and can later be migrated to Nuxt or Vite with single-file components.

**Backend:** Node 22 built-in HTTP + SQLite. Password hashes via `scrypt`, random HttpOnly session tokens stored as SHA-256 hashes, role-based checks, session expiry, same-origin write protections, transactional checkout, server-side pricing validation, event-date constraints, overlapping service booking detection, private file serving and approval workflows. This is a practical MVP **not a substitute for production hardening**.

**Persistence:** `data/yaadifyos.sqlite` (WAL enabled). Six illustrative events, fourteen services, two suppliers and two seeded booking requests. Default currency calculations are illustrative (`AED 0.98` and `USD 0.27` per SAR) and MUST be replaced with authorized live FX and payment-time locked quotes in production.

## Routes

| Path | Purpose |
|---|---|
| `/` | Homepage |
| `/events` | Event directory |
| `/events/:slug` | Event marketplace (e.g. `/events/gitex-2026`) |
| `/services` | Services, filters and categories |
| `/services/:id` | Service details |
| `/book/:serviceId?event=:id` | Booking configuration, dates and times |
| `/cart` | Cart and demo checkout |
| `/success` | Booking confirmation |
| `/bookings` | Customer bookings |
| `/media` | Private media hub |
| `/exhibitor` | Exhibitor workspace |
| `/supplier` | Supplier portal |
| `/organizer` | Organizer workspace |
| `/admin` | Super admin |
| `/concierge` | Rules-based concierge |
| `/city`, `/crew`, `/connect`, `/creators` | Operating system modules |
| `/profile` | Profile, settings and role switching |

## API overview

REST JSON under `/api/`:

```
GET   /api/health
GET   /api/bootstrap
GET   /api/session
POST  /api/auth/login
POST  /api/auth/demo            # only when DEMO_MODE=1
POST  /api/auth/logout
GET   /api/events?q=&city=
GET   /api/services?module=
POST  /api/checkout             # atomic booking insert, no payment
GET   /api/bookings
PATCH /api/bookings/:id/status
POST  /api/bookings/:id/cancel
GET   /api/dashboard
GET   /api/suppliers
PATCH /api/supplier/availability
GET   /api/media
POST  /api/media                # base64 image/pdf <=6 MB
PATCH /api/media/:id/approval
GET   /api/media/:id/file?download=1
POST  /api/concierge/chat      # rules-based, not AI
```

The full request/response definitions are in [`docs/openapi.yaml`](docs/openapi.yaml).

## Test the app

```bash
npm test
npm run check
```

The tests launch a separate API server on a random local port using a temporary SQLite database. They cover catalog loading, PWA manifest, authorization, checkout persistence, price calculation, time-slot collisions, supplier assignments, status updates, availability, cancellation, private uploads, media approval and concierge responses.

## Environment variables

| Variable | Default | Usage |
|---|---|---|
| `PORT` | `4173` | Web server port |
| `HOST` | `127.0.0.1` | Listening interface; use `0.0.0.0` for LAN/container |
| `DATA_DIR` | `./data` | SQLite database directory |
| `UPLOAD_DIR` | `./uploads` | Private file storage directory |
| `DEMO_MODE` | `1` | Enable one-tap demo role switching |
| `COOKIE_SECURE` | unset | Set to `1` when HTTPS is terminated in front of app |

No real API keys, third-party accounts or payment credentials are needed.

## Move to the existing Yaadify technology stack

**Recommended:** retain the Vue interface and REST contract, rebuild the API as a Laravel application with MySQL, then integrate auth, events, suppliers, reservations and media workflows with Yaadify's existing users. The migration SQL design is provided in `docs/mysql-schema.sql`. `docs/architecture.md` contains a concrete phased approach and production-readiness checklist.

A source-code integration with the existing Yaadify app **has not happened**; no code or database from the existing product was provided or modified.

## Important notes

1. **The dates, names, venues and prices are demonstrative; the displayed event schedules are NOT verified official schedules.** Confirm dates before selling travel services.
2. **Checkout is a demo reservation request.** There are no payment-provider APIs, financial settlements, taxes, invoices or client charges.
3. Video transcoding, AI-powered reels, speaker extraction, hotel booking, matchmaking and UGC licensing are clearly identified roadmap integrations, not silently simulated.
4. No automatic background push delivery is configured. The service worker is ready to receive future push payloads when a production push server and opt-in subscription endpoint are added.
5. Keep the `uploads/` directory private, add object storage and malware scanning before production, and implement tenancy-specific access policies.

© YaadifyOS concept and implementation. Bundled Vue runtime © Vue contributors (MIT license). See `THIRD_PARTY_NOTICES.md`.
