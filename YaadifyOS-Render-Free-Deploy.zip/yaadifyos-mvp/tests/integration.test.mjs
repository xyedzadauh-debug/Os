import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'yaadifyos-test-'));
const port = 42000 + Math.floor(Math.random() * 10000);
const base = `http://127.0.0.1:${port}`;
let server;
let customerCookie;
let adminCookie;
let supplierCookie;
let bookingId;
let uploadedMediaId;
const tinyPNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScL/nwAAAABJRU5ErkJggg==';

async function api(url, { method='GET', json, cookie }={}) {
 const headers={}; if(json){headers['Content-Type']='application/json'};if(cookie)headers.Cookie=cookie;
 const res=await fetch(base+url,{method,headers,body:json?JSON.stringify(json):undefined,redirect:'manual'});
 const body=await res.json();return {status:res.status,body,cookie:res.headers.get('set-cookie')};
}
async function login(role){const r=await api('/api/auth/demo',{method:'POST',json:{role}});assert.equal(r.status,200);return r.cookie.split(';')[0];}
async function boot(){for(let i=0;i<45;i++){try{const r=await api('/api/health');if(r.status===200)return}catch{}await new Promise(resolve=>setTimeout(resolve,100));}throw Error('Test server did not start');}

test('YaadifyOS end-to-end API workflows', async t=>{
 server=spawn(process.execPath,['server.mjs'],{cwd:root,env:{...process.env,PORT:String(port),DATA_DIR:dir,UPLOAD_DIR:path.join(dir,'uploads'),HOST:'127.0.0.1',DEMO_MODE:'1'},stdio:'ignore'});
 t.after(()=>{server.kill();fs.rmSync(dir,{recursive:true,force:true});});
 await boot();
 await t.test('Public PWA and catalog endpoints',async()=>{
  const r=await api('/api/bootstrap');assert.equal(r.status,200);assert.equal(r.body.events.length,6);assert.equal(r.body.services.length,14);assert.equal(r.body.currencies.USD,0.27);
  const unauth=await api('/api/bookings');assert.equal(unauth.status,401);
  const manifest=await fetch(base+'/manifest.webmanifest');assert.equal(manifest.status,200);assert.equal((await manifest.json()).display,'standalone');
  const vue=await fetch(base+'/assets/vue.global.js');assert.equal(vue.status,200);assert.ok((await vue.text()).length>100000);
 });
 await t.test('Role-based demo sessions and checkout persistence',async()=>{
  customerCookie=await login('customer');adminCookie=await login('admin');supplierCookie=await login('supplier');
  const cart={currency:'AED',items:[{serviceId:1,eventId:1,date:'2026-12-07',time:'12:00',duration:'half',units:2,notes:'QA walkthrough'}]};
  const p=await api('/api/checkout',{method:'POST',json:cart});assert.equal(p.status,401);
  const r=await api('/api/checkout',{method:'POST',cookie:customerCookie,json:cart});assert.equal(r.status,201);assert.equal(r.body.bookings.length,1);
  bookingId=r.body.bookings[0].id;assert.equal(r.body.bookings[0].price_sar,2400);assert.equal(r.body.bookings[0].total_display,2352);
  const mine=await api('/api/bookings',{cookie:customerCookie});assert.equal(mine.status,200);assert.ok(mine.body.bookings.some(x=>x.id===bookingId));
  const duplicate=await api('/api/checkout',{method:'POST',cookie:customerCookie,json:cart});assert.equal(duplicate.status,409);
  const supplier=await api('/api/bookings',{cookie:supplierCookie});assert.ok(supplier.body.bookings.some(x=>x.id===bookingId));
  const forbidden=await api(`/api/bookings/${bookingId}/status`,{method:'PATCH',cookie:customerCookie,json:{status:'completed'}});assert.equal(forbidden.status,403);
 });
 await t.test('Supplier confirmation, availability, customer cancellation',async()=>{
  const confirm=await api(`/api/bookings/${bookingId}/status`,{method:'PATCH',cookie:supplierCookie,json:{status:'confirmed'}});assert.equal(confirm.status,200);
  const availability=await api('/api/supplier/availability',{method:'PATCH',cookie:supplierCookie,json:{available:false}});assert.equal(availability.status,200);assert.equal(availability.body.available,false);
  const cancelled=await api(`/api/bookings/${bookingId}/cancel`,{method:'POST',cookie:customerCookie});assert.equal(cancelled.status,200);
  const revive=await api(`/api/bookings/${bookingId}/status`,{method:'PATCH',cookie:adminCookie,json:{status:'completed'}});assert.equal(revive.status,409);
 });
 await t.test('Authenticated media uploads, moderation, and private delivery',async()=>{
  const data=`data:image/png;base64,${tinyPNG}`;
  const upload=await api('/api/media',{method:'POST',cookie:customerCookie,json:{bookingId:1,title:'QA test upload',fileName:'test.png',mime:'image/png',data}});
  assert.equal(upload.status,201);assert.equal(upload.body.approved,false);uploadedMediaId=upload.body.id;
  const customerList=await api('/api/media',{cookie:customerCookie});assert.ok(!customerList.body.media.some(m=>m.id===uploadedMediaId));
  const adminList=await api('/api/media',{cookie:adminCookie});assert.ok(adminList.body.media.some(m=>m.id===uploadedMediaId));
  const forbidden=await api(`/api/media/${uploadedMediaId}/file`,{cookie:customerCookie});assert.equal(forbidden.status,404);
  const approval=await api(`/api/media/${uploadedMediaId}/approval`,{method:'PATCH',cookie:adminCookie,json:{approved:true}});assert.equal(approval.status,200);
  const view=await fetch(base+`/api/media/${uploadedMediaId}/file`,{headers:{Cookie:customerCookie}});assert.equal(view.status,200);assert.equal(view.headers.get('content-type'),'image/png');
  const supplierApprove=await api(`/api/media/${uploadedMediaId}/approval`,{method:'PATCH',cookie:supplierCookie,json:{approved:false}});assert.equal(supplierApprove.status,403);
 });
 await t.test('Concierge response, input validation, dashboard metrics',async()=>{
  const chat=await api('/api/concierge/chat',{method:'POST',json:{message:'I need a videographer for GITEX Dubai'}});assert.equal(chat.status,200);assert.ok(chat.body.services.length>0);assert.match(chat.body.mode,/rules-based/);
  const invalid=await api('/api/checkout',{method:'POST',cookie:adminCookie,json:{currency:'SAR',items:[{serviceId:1,eventId:1,date:'2026-12-30',time:'10:00',duration:'full',units:1}]}});assert.equal(invalid.status,400);
  const admin=await api('/api/dashboard',{cookie:adminCookie});assert.equal(admin.status,200);assert.ok(admin.body.totals.bookings>=3);
  const localStatic=await fetch(base+'/../../server.mjs');assert.notEqual(localStatic.status,200);
 });
});
