/* YaadifyOS Vue 3 runtime application. No build step or external JavaScript CDN needed. */
(() => {
'use strict';
const { createApp } = Vue;
const ICONS = {
  home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
  camera:'<path d="M14 4h-4L8 7H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-4z"/><circle cx="12" cy="14" r="4"/>',
  video:'<rect x="3" y="5" width="13" height="14" rx="2"/><path d="m16 10 5-3v10l-5-3"/>',
  briefcase:'<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 13h18"/>',
  users:'<path d="M16 20v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M16 4.1a4 4 0 0 1 0 7.8M22 20v-2a4 4 0 0 0-3-3.87"/><circle cx="9" cy="8" r="4"/>',
  map:'<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3zM9 3v15M15 6v15"/>',
  'map-pin':'<path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0z"/><circle cx="12" cy="10" r="2.5"/>',
  sparkles:'<path d="m12 3 1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5zM5 17l.7 2.3L8 20l-2.3.7L5 23l-.7-2.3L2 20l2.3-.7zM19 2l.5 1.5L21 4l-1.5.5L19 6l-.5-1.5L17 4l1.5-.5z"/>',
  'arrow-right':'<path d="M5 12h14M13 6l6 6-6 6"/>',
  'arrow-left':'<path d="M19 12H5m6-6-6 6 6 6"/>',
  'chevron-right':'<path d="m9 18 6-6-6-6"/>',
  'chevron-down':'<path d="m6 9 6 6 6-6"/>',
  check:'<path d="m5 12 4 4L19 6"/>',
  close:'<path d="M18 6 6 18M6 6l12 12"/>',
  star:'<path d="m12 2 3.2 6.5 7.2 1-5.2 5.1 1.2 7.2L12 18.4 5.6 21.8l1.2-7.2L1.6 9.5l7.2-1z"/>',
  heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 1 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>',
  bag:'<path d="M4 8h16l-1 13H5L4 8zM9 9V6a3 3 0 0 1 6 0v3"/>',
  credit:'<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>',
  file:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M8 13h8M8 17h6"/>',
  image:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
  download:'<path d="M12 3v12m-4-4 4 4 4-4M4 17v4h16v-4"/>',
  upload:'<path d="M12 16V3m-4 4 4-4 4 4M4 17v4h16v-4"/>',
  bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>',
  settings:'<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1l2-1.5-2-3.5-2.4 1a8 8 0 0 0-1.8-1L14.3 3h-4.6L9.3 6a8 8 0 0 0-1.8 1l-2.4-1-2 3.5 2 1.5a7 7 0 0 0 0 2L3 14.5l2 3.5 2.4-1a8 8 0 0 0 1.8 1l.5 3h4.6l.5-3a8 8 0 0 0 1.8-1l2.4 1 2-3.5-2-1.5a7 7 0 0 0 .1-1z"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
  globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c-5 5-5 13 0 18M12 3c5 5 5 13 0 18"/>',
  moon:'<path d="M20 15.3A8 8 0 0 1 8.7 4a8 8 0 1 0 11.3 11.3z"/>',
  sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M19.1 4.9l-1.4 1.4M6.3 17.7l-1.4 1.4"/>',
  chart:'<path d="M3 3v18h18M7 16v-5M12 16V7M17 16V4"/>',
  shield:'<path d="m12 2 9 4v6c0 5-3.8 8-9 10-5.2-2-9-5-9-10V6zM9 12l2 2 4-4"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',
  filter:'<path d="M4 7h16M7 12h10M10 17h4"/>',
  message:'<path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5 9 9 0 0 1-4-.9L3 21l1.9-5.5a8.5 8.5 0 1 1 16.1-4z"/>',
  arrowup:'<path d="M12 19V5M6 11l6-6 6 6"/>',
  'external-link':'<path d="M14 3h7v7M10 14 21 3M20 13v8H3V4h8"/>',
  'log-out':'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
  'plus':'<path d="M12 5v14M5 12h14"/>',
  minus:'<path d="M5 12h14"/>',
  trash:'<path d="M3 6h18M8 6V4h8v2M6 6l1 15h10l1-15M10 10v7M14 10v7"/>',
  'headphones':'<path d="M3 13v-2a9 9 0 0 1 18 0v2M3 13h4v7H5a2 2 0 0 1-2-2zM21 13h-4v7h2a2 2 0 0 0 2-2z"/>',
  'building':'<rect x="4" y="2" width="16" height="20" rx="1"/><path d="M8 6h2M14 6h2M8 10h2M14 10h2M8 14h2M14 14h2M10 22v-4h4v4"/>',
  utensils:'<path d="M4 2v8a4 4 0 0 0 8 0V2M8 2v20M20 2c-6 3-5 9 0 11v9"/>',
  'clapperboard':'<path d="M3 11h18v10H3zM3 7l17-4 1 5-18 4zM7 6l3 4M14 4l3 5"/>',
  mic:'<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 17v5M8 22h8"/>',
  smartphone:'<rect x="6" y="2" width="12" height="20" rx="2"/><path d="M11 18h2"/>'
};
const LOCALE = {
  en: { home:'Home',explore:'Explore',bookings:'Bookings',media:'Media',profile:'Profile',search:'Search events, services or cities',discover:'Discover the extraordinary',subtitle:'The entire event experience. One beautiful place.',viewEvents:'Explore events',bookServices:'Book services',featured:'Featured events',upcoming:'Upcoming events',exploreAll:'See all',popular:'Popular services',handpicked:'Handpicked for your next big moment',categories:'Everything your event needs',booking:'Book your service',chooseDate:'Choose your date',chooseTime:'Select start time',duration:'Duration',hour:'Hourly',half:'Half day · 4h',full:'Full day · 8h',quantity:'Team / quantity',addCart:'Add to cart',checkout:'Checkout',cart:'Your cart',emptyCart:'Your cart is empty',continue:'Continue exploring',confirm:'Place demo booking',paymentNote:'Demo checkout · No actual payment will be collected',customerDashboard:'Your bookings',myMedia:'Media library',download:'Download',event:'Event',service:'Service',city:'City',showAll:'All services',noResults:'No results found',signIn:'Sign in',logOut:'Sign out',switchRole:'Switch demo role',yourAccount:'Your workspace',darkMode:'Dark mode',notifications:'Notifications',currency:'Currency',language:'Language',supplier:'Supplier portal',organizer:'Organizer dashboard',admin:'Super admin',assistant:'AI concierge',guest:'Guest explorer',details:'View details',bookNow:'Book now',back:'Back',notes:'Instructions for your crew (optional)',gallery:'Your delivered content, all in one place',dashboard:'Dashboard',help:'How can I help?',message:'Ask about coverage, crew, dinners…',send:'Send',filter:'Filter',all:'All',available:'Available for assignments',save:'Save',upload:'Upload media',remove:'Remove',cancel:'Cancel',confirmed:'Confirmed',pending:'Pending',completed:'Completed',rejected:'Rejected',cancelled:'Cancelled',role:'Role',demo:'DEMO',roleHelp:'Explore every portal with instant demo access.',mobileExperience:'Made for event days',status:'Status',live:'Live',learnMore:'Explore module' },
  ar: { home:'الرئيسية',explore:'استكشف',bookings:'الحجوزات',media:'الوسائط',profile:'الملف الشخصي',search:'ابحث عن فعالية أو خدمة أو مدينة',discover:'اكتشف تجربة استثنائية',subtitle:'كل ما تحتاجه لفعاليتك في مكان واحد.',viewEvents:'استكشف الفعاليات',bookServices:'احجز الخدمات',featured:'فعاليات مميزة',upcoming:'الفعاليات القادمة',exploreAll:'عرض الكل',popular:'خدمات شائعة',handpicked:'خدمات مختارة لفعاليتك القادمة',categories:'كل ما تحتاجه فعاليتك',booking:'احجز خدمتك',chooseDate:'اختر التاريخ',chooseTime:'اختر وقت البداية',duration:'المدة',hour:'بالساعة',half:'نصف يوم · ٤ ساعات',full:'يوم كامل · ٨ ساعات',quantity:'العدد',addCart:'إضافة إلى السلة',checkout:'إتمام الطلب',cart:'سلة المشتريات',emptyCart:'سلتك فارغة',continue:'متابعة الاستكشاف',confirm:'تأكيد الحجز التجريبي',paymentNote:'تجربة دفع فقط · لن يتم تحصيل أي مبلغ',customerDashboard:'حجوزاتي',myMedia:'مكتبة الوسائط',download:'تنزيل',event:'الفعالية',service:'الخدمة',city:'المدينة',showAll:'جميع الخدمات',noResults:'لا توجد نتائج',signIn:'تسجيل الدخول',logOut:'تسجيل الخروج',switchRole:'تغيير الدور التجريبي',yourAccount:'مساحة العمل',darkMode:'الوضع الداكن',notifications:'الإشعارات',currency:'العملة',language:'اللغة',supplier:'بوابة الموردين',organizer:'لوحة المنظم',admin:'المشرف العام',assistant:'المساعد الذكي',guest:'وضع الزائر',details:'التفاصيل',bookNow:'احجز الآن',back:'رجوع',notes:'تعليمات إضافية للفريق (اختياري)',gallery:'كل محتواك في مكان واحد',dashboard:'لوحة التحكم',help:'كيف يمكنني مساعدتك؟',message:'اسأل عن التصوير أو الطاقم أو العشاء…',send:'إرسال',filter:'تصفية',all:'الكل',available:'متاح للمهام',save:'حفظ',upload:'رفع الوسائط',remove:'حذف',cancel:'إلغاء',confirmed:'مؤكد',pending:'قيد الانتظار',completed:'مكتمل',rejected:'مرفوض',cancelled:'ملغي',role:'الدور',demo:'تجريبي',roleHelp:'استكشف جميع البوابات عبر الدخول التجريبي.',mobileExperience:'مصمم لأيام الفعاليات',status:'الحالة',live:'مباشر',learnMore:'استكشف القسم' }
};
const MODULES = [
  { id:'media', name:'MediaOS', ar:'الإعلام', subtitle:'Capture every moment', icon:'camera', color:'lavender', path:'/services?module=media' },
  { id:'crew', name:'CrewOS', ar:'فرق العمل', subtitle:'People who make it happen', icon:'users', color:'orange', path:'/crew' },
  { id:'city', name:'CityOS', ar:'المدينة', subtitle:'Your city, sorted', icon:'map-pin', color:'teal', path:'/city' },
  { id:'connect', name:'ConnectOS', ar:'تواصل', subtitle:'Make meaningful connections', icon:'message', color:'pink', path:'/connect' },
  { id:'creator', name:'CreatorOS', ar:'المبدعون', subtitle:'Create authentic buzz', icon:'sparkles', color:'yellow', path:'/creators' }
];
const PHOTO = key => `https://images.unsplash.com/${key}?auto=format&fit=crop&w=1000&q=78`;
const imgFallback = '/assets/event-fallback.svg';
const moneyCompact = (val, currency) => { try { return new Intl.NumberFormat('en', { maximumFractionDigits: 0 }).format(val) + ' ' + currency; } catch { return val + ' ' + currency; } };
const queryPath = p => new URL(p,location.origin);
const local = (key,fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };
const formatDate = (date, locale='en') => { try { return new Intl.DateTimeFormat(locale==='ar'?'ar-SA':'en-US', { month:'short', day:'numeric', timeZone:'UTC' }).format(new Date(date+'T12:00:00Z')); } catch { return date; } };
const dateRange = (start, end, max = 12) => {
 const dates = []; if (!start || !end) return dates;
 const a = new Date(start + 'T12:00:00Z'); const b = new Date(end + 'T12:00:00Z');
 for (let d = a; d <= b && dates.length < max; d = new Date(d.getTime()+86400000)) dates.push(d.toISOString().slice(0,10)); return dates;
};
async function request(url, options={}) {
 const res=await fetch(url,{credentials:'same-origin',headers:{ ...(options.body && !(options.body instanceof FormData) ? {'Content-Type':'application/json'} : {}), ...(options.headers||{}) },...options});
 let body; try { body=await res.json(); } catch { body={}; }
 if(!res.ok) throw Error(body.error || `Request failed (${res.status})`);
 return body;
}
const app = createApp({
 data() { return {
  path: location.pathname + location.search, modules:MODULES, events:[], services:[], user:null, dashboard:null, bookings:[], media:[], suppliers:[],
  busy:false, initializing:true, offline:!navigator.onLine, mobileSearch:false, mobileMenu:false,
  locale:local('yos-language','en'), theme:local('yos-theme','light'), currency:local('yos-currency','SAR'),
  rates:{SAR:1,AED:0.98,USD:0.27}, demo:true, search:'', eventsQuery:'', cityFilter:'All', moduleFilter:'all',
  cart:local('yos-cart',[]), booking:{eventId:null,date:'',time:'10:00',duration:'half',units:1,notes:''},
  loginOpen:false, loginReturn:null, loginEmail:'',loginPassword:'',roleSelection:'customer', loginBusy:false,
  toast:'',toastType:'success',detailTab:'overview', dashTab:'overview', mediaUploadOpen:false,
  uploadBookingId:'',uploadTitle:'',uploadFile:null, uploadSending:false,
  supplierAvailable:true, conciergeQuery:'',chat:[{who:'assistant',text:'Hi! I’m your event copilot. Tell me the event, city and services you need, and I’ll help you build a plan.'}],chatBusy:false,
  notificationGranted: typeof Notification !== 'undefined' && Notification.permission === 'granted',
  successRefs:[], eventPill:'All', cityChoice:'Riyadh', inviteVisible:false,
  sampleCities:[{name:'Riyadh',tag:'A world of possibilities',image:'photo-1512453979798-5ea266f8880c'},{name:'Dubai',tag:'Where ideas meet',image:'photo-1518684079-3c830dcef090'}]
 };},
 computed: {
  t(){return LOCALE[this.locale] || LOCALE.en;},
  pathname(){return this.path.split('?')[0];},
  current(){
   const p=this.pathname;
   if(p==='/')return 'home'; if(p==='/events')return 'events'; if(p.startsWith('/events/'))return 'event';
   if(p==='/services')return 'services'; if(p.startsWith('/services/'))return 'service'; if(p.startsWith('/book/'))return 'book';
   if(p==='/cart')return 'cart'; if(p==='/bookings')return 'bookings'; if(p==='/media')return 'media';
   if(p==='/supplier')return 'supplier';if(p==='/admin')return 'admin';if(p==='/organizer')return 'organizer';
   if(p==='/exhibitor')return 'exhibitor'; if(p==='/concierge')return 'concierge';if(p==='/profile')return 'profile';
   if(p==='/city')return 'city';if(p==='/crew')return 'crew';if(p==='/connect')return 'connect';if(p==='/creators')return 'creator';
   if(p==='/success')return 'success';return 'home';
  },
  activeEvent(){ const slug=this.pathname.split('/')[2]; return this.events.find(e=>e.slug===slug); },
  activeService(){ const id=Number(this.pathname.split('/')[2]); return this.services.find(s=>s.id===id); },
  activeBookingEvent(){return this.events.find(e=>e.id===Number(this.booking.eventId));},
  filteredEvents(){return this.events.filter(e => (this.cityFilter==='All'||e.city===this.cityFilter) && (!this.eventsQuery || `${e.name} ${e.category} ${e.city}`.toLowerCase().includes(this.eventsQuery.toLowerCase())) && (this.eventPill==='All'||e.category===this.eventPill));},
  activeModuleFilter(){return new URLSearchParams(this.path.split('?')[1]||'').get('module')||this.moduleFilter;},
  filteredServices(){const qs=new URLSearchParams(this.path.split('?')[1]||'');const mod=qs.get('module')||this.moduleFilter;return this.services.filter(s=>(!mod||mod==='all'||s.module===mod)&&(!this.search||`${s.title} ${s.description} ${s.category}`.toLowerCase().includes(this.search.toLowerCase())));},
  eventServices(){return this.services.filter(s=>(this.moduleFilter==='all'||s.module===this.moduleFilter)&&(!this.search||`${s.title} ${s.category}`.toLowerCase().includes(this.search.toLowerCase())));},
  cartTotal(){return this.cart.reduce((sum,item)=>sum+(this.services.find(s=>s.id===Number(item.serviceId))?.[item.duration==='hour'?'hourly_sar':item.duration==='half'?'halfday_sar':'fullday_sar']||0)*Number(item.units||1),0);},
  bookingPrice(){const s=this.activeService;if(!s)return 0;return s[this.booking.duration==='hour'?'hourly_sar':this.booking.duration==='half'?'halfday_sar':'fullday_sar'] * this.booking.units;},
  availableDates(){const e=this.activeBookingEvent;return e?dateRange(e.starts_on,e.ends_on):[];},
  timeSlots(){return Array.from({length:23},(_,i)=>{let total=7*60+i*30;return `${String(Math.floor(total/60)).padStart(2,'0')}:${String(total%60).padStart(2,'0')}`;}).filter(v=>Number(v.slice(0,2)) < ({hour:22,half:19,full:15}[this.booking.duration]||19));},
  myRole(){return this.user?.role||'guest';},
  greeting(){const h=new Date().getHours();return h<12?'Good morning':h<18?'Good afternoon':'Good evening';},
  featured(){return this.events.filter(e=>e.featured).slice(0,3);},
  distinctCities(){return ['All',...new Set(this.events.map(e=>e.city))];},
  eventCategories(){return ['All',...new Set(this.events.map(e=>e.category))];},
  isDashboard(){return ['bookings','admin','supplier','organizer','exhibitor'].includes(this.current);},
  isStandalone(){return window.matchMedia?.('(display-mode: standalone)').matches||false;},
 },
 methods: {
  icon(name){return ICONS[name]||ICONS.star;}, img:PHOTO, formatDate, imgErr(e){if(!e.target.src.endsWith('event-fallback.svg'))e.target.src=imgFallback;},
  cash(sar){return moneyCompact(Math.round(sar * (this.rates[this.currency]||1)),this.currency);},
  shortDate(date){return formatDate(date,this.locale);},
  range(e){return `${this.shortDate(e.starts_on)} – ${this.shortDate(e.ends_on)} · ${e.starts_on.slice(0,4)}`;},
  categoryName(m){return this.locale==='ar' ? m.ar : m.name;},
  moduleTitle(key){return MODULES.find(m=>m.id===key)?.name||'Services';},
  initials(name){return String(name||'G').split(/\s+/).slice(0,2).map(s=>s[0]).join('').toUpperCase();},
  savePrefs(){localStorage.setItem('yos-language',JSON.stringify(this.locale));localStorage.setItem('yos-theme',JSON.stringify(this.theme));localStorage.setItem('yos-currency',JSON.stringify(this.currency));document.documentElement.dir=this.locale==='ar'?'rtl':'ltr';document.documentElement.lang=this.locale;document.documentElement.dataset.theme=this.theme;},
  setLocale(lang){this.locale=lang;this.savePrefs();}, setTheme(theme){this.theme=theme;this.savePrefs();},setCurrency(currency){this.currency=currency;this.savePrefs();this.tip('Currency uses illustrative demo rates, not live FX.');},
  tip(msg,type='success'){this.toast=msg;this.toastType=type;clearTimeout(this._toastTimer);this._toastTimer=setTimeout(()=>this.toast='',4200);},
  go(to){
   const path=typeof to==='string'?to:'/';if(this.path===path){window.scrollTo({top:0,behavior:'smooth'});return;}
   history.pushState({},'',path);this.path=path;this.mobileMenu=false;this.mobileSearch=false;this.search='';this.detailTab='overview';this.dashTab='overview';this.moduleFilter='all';
   if(this.current==='book')this.setupBooking();
   if(this.current==='crew')this.requestSuppliers();
   if(['bookings','supplier','admin','organizer','exhibitor','media'].includes(this.current))this.reloadWorkspace();
   window.scrollTo({top:0,behavior:'smooth'});
  },
  serviceGo(id,eventId){this.go(`/services/${id}${eventId?'?event='+eventId:''}`);},
  bookService(service,eventId){
   const contextEvent=Number(new URLSearchParams(this.path.split('?')[1]||'').get('event'));
   const e=eventId||this.activeEvent?.id||(this.events.some(x=>x.id===contextEvent)?contextEvent:null)||this.booking.eventId||this.events[0]?.id;
   this.go(`/book/${service.id}?event=${e||''}`);
  },
  setupBooking(){
   const qs=new URLSearchParams(this.path.split('?')[1]||'');let eventId=Number(qs.get('event'));
   if(!this.events.some(e=>e.id===eventId))eventId=this.events[0]?.id;
   const e=this.events.find(x=>x.id===eventId);
   this.booking={eventId,date:e?.starts_on||'',time:'10:00',duration:'half',units:1,notes:''};
  },
  changeBookingEvent(id){this.booking.eventId=Number(id);this.booking.date=this.activeBookingEvent?.starts_on||'';},
  adjustQty(delta){this.booking.units=Math.max(1,Math.min(10,this.booking.units+delta));},
  addCart(){
   if(!this.activeService||!this.activeBookingEvent||!this.booking.date||!this.booking.time)return this.tip('Select your event, date and time.','error');
   if(this.cart.length>=12)return this.tip('The demo cart supports up to 12 items.','error');
   const item={key:Date.now()+'-'+Math.random().toString(36).slice(2,8),serviceId:this.activeService.id,eventId:this.booking.eventId,date:this.booking.date,time:this.booking.time,duration:this.booking.duration,units:this.booking.units,notes:this.booking.notes};
   this.cart.push(item);this.persistCart();this.tip('Added to your event cart.');this.go('/cart');
  },
  persistCart(){localStorage.setItem('yos-cart',JSON.stringify(this.cart));},
  deleteCart(key){this.cart=this.cart.filter(i=>i.key!==key);this.persistCart();},
  cartService(item){return this.services.find(s=>s.id===Number(item.serviceId))||{};},
  cartEvent(item){return this.events.find(e=>e.id===Number(item.eventId))||{};},
  itemPrice(item){const s=this.cartService(item);return (s[item.duration==='hour'?'hourly_sar':item.duration==='half'?'halfday_sar':'fullday_sar']||0)*item.units;},
  async checkout(){
   if(!this.user){this.loginReturn='/cart';this.loginOpen=true;return this.tip('Sign in to place your demo booking.','error');}
   if(!['customer','exhibitor','admin'].includes(this.user.role))return this.tip('Switch to a customer or exhibitor role to book.','error');
   if(!this.cart.length)return;
   this.busy=true;
   try {const data=await request('/api/checkout',{method:'POST',body:JSON.stringify({items:this.cart,currency:this.currency})});this.successRefs=data.bookings;this.cart=[];this.persistCart();await this.reloadWorkspace();this.go('/success');this.tip('Booking requests created successfully.');
    if(this.notificationGranted)new Notification('YaadifyOS · Booking received',{body:'Your demo booking request is pending confirmation.'});
   }catch(e){this.tip(e.message,'error');}finally{this.busy=false;}
  },
  async init(){
   this.savePrefs();window.addEventListener('popstate',()=>{this.path=location.pathname+location.search;if(this.current==='book')this.setupBooking();this.reloadWorkspace();});
   window.addEventListener('online',()=>{this.offline=false;this.reloadBootstrap();});window.addEventListener('offline',()=>this.offline=true);
   await this.reloadBootstrap();if(this.current==='book')this.setupBooking();if(this.current==='crew')this.requestSuppliers();await this.reloadWorkspace();this.initializing=false;
   if('serviceWorker' in navigator && location.protocol!=='file:')navigator.serviceWorker.register('/sw.js').catch(()=>{});
  },
  async reloadBootstrap(){
   try {const b=await request('/api/bootstrap');this.events=b.events;this.services=b.services;this.user=b.user;this.rates=b.currencies||this.rates;this.demo=b.demo;localStorage.setItem('yos-public-cache',JSON.stringify({events:b.events,services:b.services,currencies:b.currencies}));}
   catch(e){const cached=local('yos-public-cache',null);if(cached){this.events=cached.events;this.services=cached.services;this.rates=cached.currencies||this.rates;this.tip('Offline preview: showing saved event listings.','error');}else{this.tip('Could not load the demo API. Check that the server is running.','error');}}
  },
  async reloadWorkspace(){
   if(!this.user)return;
   try{const [d,b,m]=await Promise.all([request('/api/dashboard'),request('/api/bookings'),request('/api/media')]);this.dashboard=d;this.bookings=b.bookings;this.media=m.media;
    if(this.user.role==='supplier'){const profile=await request('/api/suppliers');this.suppliers=profile.suppliers;this.supplierAvailable=!!profile.suppliers.find(s=>s.id===this.user.id)?.available;}
   }catch(e){if(navigator.onLine)this.tip(e.message,'error');}
  },
  async demoLogin(role){
   this.loginBusy=true;
   try{const data=await request('/api/auth/demo',{method:'POST',body:JSON.stringify({role})});this.user=data.user;this.loginOpen=false;this.roleSelection=role;await this.reloadWorkspace();this.tip(`Viewing as ${role} · demo mode`);const destination=this.loginReturn||this.roleLocation(role);this.loginReturn=null;this.go(destination);}
   catch(e){this.tip(e.message,'error');}finally{this.loginBusy=false;}
  },
  async login(){
   this.loginBusy=true;
   try{const data=await request('/api/auth/login',{method:'POST',body:JSON.stringify({email:this.loginEmail,password:this.loginPassword})});this.user=data.user;this.loginOpen=false;await this.reloadWorkspace();this.tip('Signed in successfully.');const destination=this.loginReturn||this.roleLocation(data.user.role);this.loginReturn=null;this.go(destination);}
   catch(e){this.tip(e.message,'error');}finally{this.loginBusy=false;}
  },
  async logout(){try{await request('/api/auth/logout',{method:'POST'});}catch{}this.user=null;this.bookings=[];this.media=[];this.dashboard=null;this.tip('Signed out.');this.go('/');},
  async cancelBooking(b){if(!confirm(`Cancel booking ${b.reference}?`))return;try{await request(`/api/bookings/${b.id}/cancel`,{method:'POST'});this.tip('Booking cancelled.');await this.reloadWorkspace();}catch(e){this.tip(e.message,'error');}},
  async updateBooking(b,status){try{await request(`/api/bookings/${b.id}/status`,{method:'PATCH',body:JSON.stringify({status})});this.tip(`Booking marked ${status}.`);await this.reloadWorkspace();}catch(e){this.tip(e.message,'error');}},
  async toggleAvailability(){try{const r=await request('/api/supplier/availability',{method:'PATCH',body:JSON.stringify({available:!this.supplierAvailable})});this.supplierAvailable=r.available;this.tip(r.available?'Your profile is marked available.':'Your profile is marked unavailable.');}catch(e){this.tip(e.message,'error');}},
  async setApproval(m,approved){try{await request(`/api/media/${m.id}/approval`,{method:'PATCH',body:JSON.stringify({approved})});this.tip(approved?'Media approved.':'Media approval revoked.');await this.reloadWorkspace();}catch(e){this.tip(e.message,'error');}},
  openMediaUpload(){if(!this.user){this.loginOpen=true;return;}this.mediaUploadOpen=true;this.uploadBookingId=this.bookings[0]?.id||'';},
  handleFile(e){this.uploadFile=e.target.files?.[0]||null;if(this.uploadFile)this.uploadTitle=this.uploadFile.name.replace(/\.[^.]+$/,'');},
  async uploadMedia(){
   if(!this.uploadFile||!this.uploadBookingId)return this.tip('Choose a booking and file.','error');
   if(this.uploadFile.size>6*1024*1024)return this.tip('Maximum file size is 6 MB.','error');
   this.uploadSending=true;
   try{
    const data=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error('Cannot read file.'));reader.readAsDataURL(this.uploadFile);});
    const r=await request('/api/media',{method:'POST',body:JSON.stringify({bookingId:Number(this.uploadBookingId),title:this.uploadTitle,fileName:this.uploadFile.name,mime:this.uploadFile.type,data})});
    this.mediaUploadOpen=false;this.uploadFile=null;this.tip(r.message);await this.reloadWorkspace();
   }catch(e){this.tip(e.message,'error');}finally{this.uploadSending=false;}
  },
  mediaUrl(m,download=false){return `/api/media/${m.id}/file${download?'?download=1':''}`;},
  async chatSend(text){
   const q=String(text||this.conciergeQuery).trim();if(!q||this.chatBusy)return;
   this.chat.push({who:'user',text:q});this.conciergeQuery='';this.chatBusy=true;
   try{const data=await request('/api/concierge/chat',{method:'POST',body:JSON.stringify({message:q})});this.chat.push({who:'assistant',text:data.reply,picks:data.services,event:data.event});}
   catch(e){this.chat.push({who:'assistant',text:'I cannot reach the demo assistant right now. Please check your connection.'});}
   finally{this.chatBusy=false;this.$nextTick(()=>{const el=this.$refs.chatScroll;if(el)el.scrollTop=el.scrollHeight;});}
  },
  async notify(){if(!('Notification' in window))return this.tip('Notifications are not supported in this browser.','error');const state=await Notification.requestPermission();this.notificationGranted=state==='granted';this.tip(state==='granted'?'Local demo notifications enabled.':'Notification permission not granted.',state==='granted'?'success':'error');},
  filterModule(module){this.moduleFilter=module;},
  goSearch(){this.eventsQuery=this.search;this.go('/events');},
  openModule(m){this.go(m.path);},
  bookingRole(){return ['admin','organizer','supplier','exhibitor'].includes(this.myRole);},
  bookingStatusColor(status){return {confirmed:'success',completed:'success',pending:'warning',cancelled:'muted',rejected:'error'}[status]||'muted';},
  roleLocation(role){return {customer:'/bookings',exhibitor:'/exhibitor',supplier:'/supplier',organizer:'/organizer',admin:'/admin'}[role]||'/profile';},
  refresh(){this.reloadBootstrap();this.reloadWorkspace();}
 },
 mounted(){this.init();},
 template:`
<div class="app-shell" :class="{'shell-rtl':locale==='ar'}">
  <aside class="desktop-side">
    <div class="side-brand" @click="go('/')" role="button" tabindex="0"><div class="logo-mark">✳</div><div class="brand-name">yaadify<span>OS</span><small>POWERED BY YAADGAAR</small></div></div>
    <div class="side-group-label">YOUR WORKSPACE</div>
    <nav class="side-nav" aria-label="Main navigation">
      <a href="/" :class="{active:current==='home'}" @click.prevent="go('/')"><app-icon name="home"/> {{t.home}}</a>
      <a href="/events" :class="{active:['events','event'].includes(current)}" @click.prevent="go('/events')"><app-icon name="calendar"/> {{t.explore}}</a>
      <a href="/services" :class="{active:['services','service','book'].includes(current)}" @click.prevent="go('/services')"><app-icon name="camera"/> Services</a>
      <a href="/bookings" :class="{active:current==='bookings'}" @click.prevent="go('/bookings')"><app-icon name="bag"/> {{t.bookings}}</a>
      <a href="/media" :class="{active:current==='media'}" @click.prevent="go('/media')"><app-icon name="image"/> {{t.media}}</a>
      <a href="/concierge" :class="{active:current==='concierge'}" @click.prevent="go('/concierge')"><app-icon name="sparkles"/> {{t.assistant}} <span class="side-new">NEW</span></a>
    </nav>
    <div class="side-group-label space-top">THE OPERATING SYSTEM</div>
    <nav class="side-nav module-nav">
      <a href="/crew" :class="{active:current==='crew'}" @click.prevent="go('/crew')"><app-icon name="users"/> CrewOS</a>
      <a href="/city" :class="{active:current==='city'}" @click.prevent="go('/city')"><app-icon name="map-pin"/> CityOS</a>
      <a href="/connect" :class="{active:current==='connect'}" @click.prevent="go('/connect')"><app-icon name="message"/> ConnectOS</a>
      <a href="/creators" :class="{active:current==='creator'}" @click.prevent="go('/creators')"><app-icon name="star"/> CreatorOS</a>
    </nav>
    <div class="side-bottom">
      <div class="sidebar-promo"><span class="mini-spark">✦</span><strong>Your event, operating beautifully.</strong><small>Everything your team needs, in one place.</small><button class="btn btn-white btn-sm" @click="go('/concierge')">Ask concierge <app-icon name="arrow-right"/></button></div>
      <button class="side-profile" @click="go('/profile')"><span class="avatar">{{initials(user?.name||'Guest')}}</span><span class="profile-label"><strong>{{user?.name||'Guest explorer'}}</strong><small>{{user?.role||'Tap to sign in'}}</small></span><app-icon name="chevron-right"/></button>
    </div>
  </aside>
  <div class="main-stage">
    <header class="topbar">
      <div class="mobile-brand" @click="go('/')"><div class="logo-mark">✳</div><span>yaadify<b>OS</b></span></div>
      <div class="top-welcome desktop-only"><span class="top-eyebrow">THE EVENT EXPERIENCE PLATFORM</span><strong>{{t.mobileExperience}} ✨</strong></div>
      <div class="top-actions">
        <div class="top-search desktop-only" @click="go('/events')"><app-icon name="search"/><span>{{t.search}}</span><kbd>⌘ K</kbd></div>
        <button class="icon-button mobile-search-toggle mobile-only" aria-label="Search" @click="mobileSearch=!mobileSearch"><app-icon name="search"/></button>
        <button class="currency-pill" @click="setCurrency(currency==='SAR'?'AED':currency==='AED'?'USD':'SAR')">{{currency}} <app-icon name="chevron-down"/></button>
        <button class="icon-button desktop-only" :title="theme==='light'?'Dark mode':'Light mode'" @click="setTheme(theme==='light'?'dark':'light')"><app-icon :name="theme==='light'?'moon':'sun'"/></button>
        <button class="icon-button top-cart" title="Cart" @click="go('/cart')"><app-icon name="bag"/><i v-if="cart.length" class="notification-dot"></i></button>
        <button class="top-avatar" @click="go('/profile')" aria-label="Open profile">{{initials(user?.name||'G')}}</button>
      </div>
    </header>
    <div v-if="mobileSearch" class="mobile-search-bar"><app-icon name="search"/><input v-model="eventsQuery" :placeholder="t.search" @keyup.enter="go('/events')"/><button @click="go('/events')">{{t.explore}}</button></div>
    <div v-if="offline" class="offline-notice"><app-icon name="bell"/> You're offline. Previously loaded listings remain available; bookings need a connection.</div>
    <main class="page-content" id="main-content">
      <template v-if="initializing"><div class="skeleton banner-skeleton"></div><div class="skeleton-row"><div class="skeleton card-skeleton" v-for="i in 3" :key="i"></div></div></template>
      <template v-else>

      <!-- HOME -->
      <div v-if="current==='home'" class="page-home">
        <div class="hero-eyebrow mobile-only"><span class="pulse"></span> ALL YOUR EVENTS, ONE OS</div>
        <section class="home-hero">
          <div class="hero-copy"><span class="hero-kicker"><span class="kicker-dot"></span> NEXT-GEN EVENT EXPERIENCE</span><h1 v-if="locale==='ar'">فعاليات استثنائية.<br><em>بكل سهولة.</em></h1><h1 v-else>Big events.<br><em>Beautifully simple.</em></h1><p>{{locale==='ar'?'التصوير والفرق الإبداعية والتواصل وتجارب المدينة — عالم الفعاليات بين يديك.':'Media, crew, connections and city experiences — the entire event ecosystem, in your pocket.'}}</p>
            <div class="hero-actions"><button class="btn btn-primary" @click="go('/events')">{{t.viewEvents}} <app-icon name="arrow-right"/></button><button class="btn btn-frost" @click="go('/concierge')"><app-icon name="sparkles"/> Ask AI concierge</button></div>
            <div class="hero-trust"><div class="avatar-stack"><span>A</span><span>M</span><span>S</span><span>+</span></div><p><b>One place for your event</b><small>From first idea to final deliverable</small></p></div>
          </div>
          <div class="hero-image-wrap"><img :src="img('photo-1540575467063-178a50c2df87')" @error="imgErr" alt="Exhibition and conference hall"/><div class="hero-image-shade"></div><div class="hero-float top-float"><span class="float-icon">✳</span><span><b>Everything, connected.</b><small>Your event. Your people. Your city.</small></span></div><div class="hero-float bottom-float"><span class="float-avatars">✦</span><span><b>Media team booked</b><small>Ready for your next big moment</small></span><app-icon name="check"/></div></div>
        </section>
        <section class="quick-search"><div class="quick-search-fields"><div class="quick-field"><app-icon name="search"/><label>WHAT ARE YOU LOOKING FOR?<input v-model="eventsQuery" placeholder="Events, services, cities..." @keyup.enter="go('/events')"/></label></div><div class="quick-field city-field"><app-icon name="map-pin"/><label>DESTINATION<select v-model="cityFilter"><option v-for="c in distinctCities" :value="c">{{c==='All'?'Anywhere':c}}</option></select></label></div></div><button class="btn btn-primary" @click="go('/events')">Explore <app-icon name="arrow-right"/></button></section>
        <section class="content-section modules-section"><div class="section-heading"><div><span class="eyebrow">ONE CONNECTED PLATFORM</span><h2>{{t.categories}}</h2></div><span class="section-subtle desktop-only">Five powerful worlds, one seamless experience.</span></div><div class="module-scroll"><button class="module-tile" v-for="m in modules" :key="m.id" @click="openModule(m)"><span class="module-icon" :class="m.color"><app-icon :name="m.icon"/></span><strong>{{categoryName(m)}}</strong><small>{{m.subtitle}}</small><app-icon name="arrow-right" class="module-arrow"/></button></div></section>
        <section class="content-section"><div class="section-heading"><div><span class="eyebrow">WHAT'S HAPPENING</span><h2>{{t.featured}}</h2></div><button class="link-button" @click="go('/events')">{{t.exploreAll}} <app-icon name="arrow-right"/></button></div><div class="event-grid featured-grid"><event-card v-for="e in featured" :key="e.id" :event="e" :locale="locale" @open="go('/events/'+e.slug)"/></div></section>
        <section class="content-section"><div class="section-heading"><div><span class="eyebrow">TRUSTED PRODUCTION</span><h2>Made for the moments that matter</h2><p class="section-explainer">From booth launches to keynote moments, book the right talent in just a few taps.</p></div><button class="link-button" @click="go('/services')">View services <app-icon name="arrow-right"/></button></div><div class="service-grid home-service-grid"><service-card v-for="s in services.slice(0,4)" :key="s.id" :service="s" :currency="currency" :rate="rates[currency]" @open="serviceGo(s.id)" @book="bookService(s)"/></div></section>
        <section class="concierge-banner"><div><span class="eyebrow">MEET YOUR EVENT COPILOT</span><h2>You have questions.<br>We've got your event.</h2><p>Find the right services, plan your day and discover what's possible.</p><button class="btn btn-white" @click="go('/concierge')">Talk to concierge <app-icon name="arrow-right"/></button></div><div class="concierge-art"><span>✳</span><i>✦</i><b>Ask me anything.</b></div></section>
      </div>

      <!-- EVENT DIRECTORY -->
      <div v-else-if="current==='events'" class="standard-page">
        <div class="page-header"><div><span class="eyebrow">DISCOVER WHAT'S NEXT</span><h1>{{locale==='ar'?'استكشف الفعاليات':'Explore events'}}<span class="heading-dot">.</span></h1><p>Discover exhibitions, plan your experience and book everything you need.</p></div><div class="small-stat desktop-only"><span class="stat-symbol">✳</span><strong>{{events.length}} curated events</strong><small>Demo event dates · Confirm before travel</small></div></div>
        <div class="filter-row"><div class="search-input"><app-icon name="search"/><input v-model="eventsQuery" :placeholder="t.search" aria-label="Search events"/><button v-if="eventsQuery" @click="eventsQuery=''" aria-label="Clear"><app-icon name="close"/></button></div><div class="select-wrap"><app-icon name="map-pin"/><select v-model="cityFilter" aria-label="City"><option v-for="c in distinctCities" :value="c">{{c==='All'?'All destinations':c}}</option></select></div></div>
        <div class="chip-scroll"><button v-for="pill in eventCategories" :class="['chip',{'selected':eventPill===pill}]" @click="eventPill=pill">{{pill}}</button></div>
        <div class="results-note">{{filteredEvents.length}} events <span>· Dates are illustrative demo data, not official event schedules</span></div>
        <div class="event-grid directory-grid"><event-card v-for="e in filteredEvents" :key="e.id" :event="e" :locale="locale" @open="go('/events/'+e.slug)"/></div><div class="empty-state" v-if="!filteredEvents.length"><app-icon name="search"/><h3>{{t.noResults}}</h3><button class="btn btn-secondary" @click="eventsQuery='';cityFilter='All';eventPill='All'">Clear filters</button></div>
      </div>

      <!-- INDIVIDUAL EVENT MARKETPLACE -->
      <div v-else-if="current==='event' && activeEvent" class="event-detail-page">
        <div class="breadcrumb"><a href="/events" @click.prevent="go('/events')">Events</a><app-icon name="chevron-right"/><span>{{activeEvent.name}}</span></div>
        <div class="event-hero"><img :src="img(activeEvent.image_key)" @error="imgErr" :alt="activeEvent.name"/><div class="event-hero-tint"></div><div class="event-hero-text"><span class="event-type">✦ {{activeEvent.category.toUpperCase()}} EXPERIENCE</span><h1>{{activeEvent.name}}</h1><div class="event-meta"><span><app-icon name="calendar"/> {{range(activeEvent)}}</span><span><app-icon name="map-pin"/> {{activeEvent.city}}, {{activeEvent.country}}</span></div><p>{{activeEvent.description}}</p><span class="demo-dates">Illustrative event date · Not an official schedule</span></div></div>
        <div class="event-summary-strip"><div><span class="summary-icon"><app-icon name="shield"/></span><span><b>Trusted professionals</b><small>Curated media and event talent</small></span></div><div><span class="summary-icon"><app-icon name="clock"/></span><span><b>Flexible bookings</b><small>Hourly, half-day or full-day</small></span></div><div><span class="summary-icon"><app-icon name="image"/></span><span><b>One media hub</b><small>All your assets in one place</small></span></div></div>
        <div class="section-heading margin-top"><div><span class="eyebrow">{{activeEvent.name.toUpperCase()}} MARKETPLACE</span><h2>Build your event team</h2><p class="section-explainer">Everything you need, from the first arrival to the final highlight.</p></div><div class="small-search desktop-only"><app-icon name="search"/><input v-model="search" placeholder="Find a service"/></div></div>
        <div class="chip-scroll"><button class="chip" :class="{selected:moduleFilter==='all'}" @click="moduleFilter='all'">All services</button><button class="chip" v-for="m in modules" :class="{selected:moduleFilter===m.id}" @click="moduleFilter=m.id">{{m.name}}</button></div>
        <div class="service-grid"><service-card v-for="s in eventServices" :key="s.id" :service="s" :currency="currency" :rate="rates[currency]" @open="serviceGo(s.id,activeEvent.id)" @book="bookService(s,activeEvent.id)"/></div>
        <div class="empty-state" v-if="!eventServices.length"><h3>No matching services</h3><button class="btn btn-secondary" @click="moduleFilter='all';search=''">Reset filters</button></div>
      </div>

      <!-- SERVICES -->
      <div v-else-if="current==='services'" class="standard-page"><div class="page-header"><div><span class="eyebrow">THE SERVICE MARKETPLACE</span><h1>{{locale==='ar'?'كل الخدمات في مكان واحد':'Everything, handled'}}<span class="heading-dot">.</span></h1><p>Vetted professionals and thoughtful services, right when you need them.</p></div><button class="btn btn-secondary desktop-only" @click="go('/concierge')"><app-icon name="sparkles"/> Help me choose</button></div>
        <div class="filter-row"><div class="search-input"><app-icon name="search"/><input v-model="search" placeholder="Search media, crew, creators..." aria-label="Search services"/></div><button class="filter-button"><app-icon name="filter"/> Browse services</button></div>
        <div class="chip-scroll"><button v-for="m in [{id:'all',name:'All services'},...modules]" :class="['chip',{'selected':activeModuleFilter===m.id}]" @click="go('/services'+(m.id==='all'?'':'?module='+m.id))">{{m.name}}</button></div>
        <div class="results-note">{{filteredServices.length}} curated services <span>· Pricing is illustrative</span></div><div class="service-grid"><service-card v-for="s in filteredServices" :key="s.id" :service="s" :currency="currency" :rate="rates[currency]" @open="serviceGo(s.id)" @book="bookService(s)"/></div>
      </div>

      <!-- SERVICE DETAIL -->
      <div v-else-if="current==='service' && activeService" class="service-detail-page">
        <div class="breadcrumb"><a href="/services" @click.prevent="go('/services')">Services</a><app-icon name="chevron-right"/><span>{{activeService.title}}</span></div>
        <div class="service-detail-layout"><div class="service-main"><div class="service-detail-image"><img :src="img(activeService.image_key)" @error="imgErr" :alt="activeService.title"/><span class="image-watermark"><span>✳</span> curated by Yaadgaar</span></div><span class="eyebrow">{{moduleTitle(activeService.module).toUpperCase()}} / {{activeService.category.toUpperCase()}}</span><h1>{{activeService.title}}</h1><p class="service-lead">{{activeService.description}}</p>
          <div class="rating-inline"><app-icon name="star"/> 4.9 <span>Curated partner service</span><span class="dot-sep">·</span><app-icon name="shield"/> Vetted team</div>
          <div class="info-block"><h3>What's included</h3><div class="feature-list"><div v-for="feature in activeService.inclusions.split(' · ')" :key="feature"><span class="feature-check"><app-icon name="check"/></span>{{feature}}</div><div><span class="feature-check"><app-icon name="check"/></span>Event-day coordination</div><div><span class="feature-check"><app-icon name="check"/></span>Dedicated booking support</div></div></div>
          <div class="info-block"><h3>How it works</h3><div class="steps-inline"><div><span>01</span><b>Pick your event</b><p>Choose where and when you need the service.</p></div><div><span>02</span><b>Confirm your request</b><p>Submit a demo reservation without payment.</p></div><div><span>03</span><b>Track in one place</b><p>Manage the request from your dashboard.</p></div></div></div>
        </div><aside class="booking-side-card"><span class="small-muted">STARTING FROM</span><div class="price-large">{{cash(activeService.hourly_sar)}} <small>/ hour</small></div><div class="side-price-row"><span>Half day · 4 hours</span><b>{{cash(activeService.halfday_sar)}}</b></div><div class="side-price-row"><span>Full day · 8 hours</span><b>{{cash(activeService.fullday_sar)}}</b></div><button class="btn btn-primary full-width" @click="bookService(activeService)">Select date & book <app-icon name="arrow-right"/></button><p class="safe-note"><app-icon name="shield"/> No payment collected in this demo</p><div class="booking-card-line"></div><div class="support-row"><span class="small-icon"><app-icon name="headphones"/></span><div><b>Questions before booking?</b><small>Our demo concierge can guide you</small></div><button @click="go('/concierge')"><app-icon name="chevron-right"/></button></div></aside></div>
        <div class="mobile-sticky-cta"><div><small>From</small><b>{{cash(activeService.hourly_sar)}}<span>/hr</span></b></div><button class="btn btn-primary" @click="bookService(activeService)">Book now <app-icon name="arrow-right"/></button></div>
      </div>

      <!-- BOOKING WORKFLOW -->
      <div v-else-if="current==='book' && activeService" class="booking-page"><div class="booking-page-header"><button class="round-back" @click="go('/services/'+activeService.id)" aria-label="Back"><app-icon name="arrow-left"/></button><div><span class="eyebrow">BOOKING STUDIO · STEP 1 OF 2</span><h1>{{locale==='ar'?'اصنع تجربتك.':'Make it yours.'}}</h1></div><button class="icon-button" @click="go('/cart')" aria-label="Cart"><app-icon name="bag"/><i v-if="cart.length" class="notification-dot"></i></button></div>
        <div class="booking-flow-layout"><div class="booking-configuration"><div class="booking-service-summary"><img :src="img(activeService.image_key)" @error="imgErr" :alt="activeService.title"/><div><span class="mini-overline">YOUR SELECTED SERVICE</span><h3>{{activeService.title}}</h3><span>✳ Curated by Yaadgaar MediaTech</span></div></div>
          <div class="booking-panel"><div class="panel-heading"><span class="step-number">1</span><div><h3>Select your event</h3><p>Where should your team arrive?</p></div></div><div class="select-full"><app-icon name="map-pin"/><select :value="booking.eventId" @change="changeBookingEvent($event.target.value)" aria-label="Choose event"><option v-for="e in events" :key="e.id" :value="e.id">{{e.name}} — {{e.city}}</option></select><app-icon name="chevron-down"/></div></div>
          <div class="booking-panel"><div class="panel-heading"><span class="step-number">2</span><div><h3>{{t.chooseDate}}</h3><p>{{activeBookingEvent?.name}} · Illustrative event dates</p></div></div><div class="date-scroller"><button v-for="d in availableDates" :key="d" class="date-tile" :class="{selected:booking.date===d}" @click="booking.date=d"><span>{{new Date(d+'T12:00:00Z').toLocaleDateString(locale==='ar'?'ar-SA':'en-US',{weekday:'short',timeZone:'UTC'})}}</span><strong>{{d.slice(-2)}}</strong><small>{{new Date(d+'T12:00:00Z').toLocaleDateString(locale==='ar'?'ar-SA':'en-US',{month:'short',timeZone:'UTC'})}}</small></button></div></div>
          <div class="booking-panel"><div class="panel-heading"><span class="step-number">3</span><div><h3>{{t.chooseTime}}</h3><p>All times are local to the event venue</p></div></div><div class="times-grid"><button v-for="tm in timeSlots" class="time-tile" :class="{selected:booking.time===tm}" @click="booking.time=tm">{{tm}}</button></div></div>
          <div class="booking-panel"><div class="panel-heading"><span class="step-number">4</span><div><h3>Duration & team</h3><p>Flexible options for your production needs</p></div></div><div class="duration-grid"><button v-for="d in [{key:'hour',name:'Hourly',sub:'1 hour',icon:'clock'},{key:'half',name:'Half day',sub:'4 hours',icon:'sun'},{key:'full',name:'Full day',sub:'8 hours',icon:'calendar'}]" class="duration-option" :class="{selected:booking.duration===d.key}" @click="booking.duration=d.key"><app-icon :name="d.icon"/><strong>{{d.name}}</strong><small>{{d.sub}}</small><i v-if="booking.duration===d.key" class="duration-check"><app-icon name="check"/></i></button></div><div class="quantity-line"><span><b>Team / quantity</b><small>Number of service units</small></span><div class="quantity-selector"><button @click="adjustQty(-1)" aria-label="Decrease quantity"><app-icon name="minus"/></button><b>{{booking.units}}</b><button @click="adjustQty(1)" aria-label="Increase quantity"><app-icon name="plus"/></button></div></div></div>
          <div class="booking-panel"><div class="panel-heading"><span class="step-number">5</span><div><h3>Special instructions</h3><p>Anything we should know about your brief?</p></div></div><textarea v-model="booking.notes" maxlength="400" placeholder="Booth number, meeting point, must-have moments, languages..." rows="3"></textarea></div>
        </div><aside class="order-summary"><span class="eyebrow">YOUR BOOKING SUMMARY</span><h3>Almost there ✦</h3><div class="summary-event"><img :src="img(activeService.image_key)" @error="imgErr" alt="Selected service"/><div><b>{{activeService.title}}</b><small>{{activeBookingEvent?.name}}</small></div></div><div class="order-line"><span>Date</span><strong>{{shortDate(booking.date)}}</strong></div><div class="order-line"><span>Start time</span><strong>{{booking.time}}</strong></div><div class="order-line"><span>Duration</span><strong>{{booking.duration==='hour'?'1 hour':booking.duration==='half'?'4 hours':'8 hours'}}</strong></div><div class="order-line"><span>Quantity</span><strong>× {{booking.units}}</strong></div><div class="order-divider"></div><div class="order-total"><span>Estimated total</span><strong>{{cash(bookingPrice)}}</strong></div><p class="tax-disclaimer">Demo pricing · Taxes and FX not finalized</p><button class="btn btn-primary full-width" @click="addCart">{{t.addCart}} <app-icon name="arrow-right"/></button><p class="safe-note"><app-icon name="shield"/> No charge until real payment integration</p></aside></div>
        <div class="mobile-sticky-cta"><div><small>Estimated total</small><b>{{cash(bookingPrice)}}</b></div><button class="btn btn-primary" @click="addCart">Add to cart <app-icon name="arrow-right"/></button></div>
      </div>

      <!-- CART / CHECKOUT -->
      <div v-else-if="current==='cart'" class="standard-page"><div class="breadcrumb"><a href="/services" @click.prevent="go('/services')">Services</a><app-icon name="chevron-right"/> Checkout</div><div class="page-header"><div><span class="eyebrow">YOUR EVENT CART</span><h1>You're nearly there<span class="heading-dot">.</span></h1><p>Review your selections before sending your demo booking requests.</p></div><span class="checkout-secure"><app-icon name="shield"/> DEMO CHECKOUT</span></div>
        <div v-if="cart.length" class="checkout-layout"><div class="cart-list"><div class="cart-item" v-for="item in cart" :key="item.key"><img :src="img(cartService(item).image_key)" @error="imgErr" :alt="cartService(item).title"/><div class="cart-item-copy"><span class="eyebrow">{{cartEvent(item).name}}</span><h3>{{cartService(item).title}}</h3><p><app-icon name="calendar"/> {{shortDate(item.date)}} · {{item.time}} · {{item.duration==='hour'?'1 hour':item.duration==='half'?'4 hours':'8 hours'}} · ×{{item.units}}</p><b>{{cash(itemPrice(item))}}</b></div><button class="delete-item" @click="deleteCart(item.key)" title="Remove"><app-icon name="trash"/></button></div><button class="continue-link" @click="go('/services')"><app-icon name="plus"/> Add more services</button></div><aside class="order-summary"><span class="eyebrow">ORDER SUMMARY</span><h3>Your event plan</h3><div class="order-line"><span>{{cart.length}} service{{cart.length!==1?'s':''}}</span><strong>{{cash(cartTotal)}}</strong></div><div class="order-line"><span>Payment processing</span><strong>Not connected</strong></div><div class="order-divider"></div><div class="order-total"><span>Total estimate</span><strong>{{cash(cartTotal)}}</strong></div><p class="tax-disclaimer">{{t.paymentNote}}. Currency conversion is illustrative.</p><button class="btn btn-primary full-width" @click="checkout" :disabled="busy"><span v-if="busy" class="button-spinner"></span>{{busy?'Placing bookings...':t.confirm}} <app-icon v-if="!busy" name="arrow-right"/></button><p class="safe-note"><app-icon name="shield"/> Requests are saved in the demo database</p></aside></div>
        <div v-else class="empty-state cart-empty"><div class="empty-orb"><app-icon name="bag"/></div><h2>{{t.emptyCart}}</h2><p>Great experiences start with a single service.</p><button class="btn btn-primary" @click="go('/services')">{{t.continue}} <app-icon name="arrow-right"/></button></div>
      </div>

      <!-- SUCCESS -->
      <div v-else-if="current==='success'" class="success-page"><div class="success-art"><app-icon name="check"/></div><span class="eyebrow">REQUESTS RECEIVED</span><h1>Your event plan is in motion.</h1><p>We've saved your demo booking requests. Track their status in your workspace. No actual payment was taken.</p><div class="success-references"><div v-for="r in successRefs" :key="r.id"><span>{{r.service_title}}</span><b>{{r.reference}}</b></div></div><button class="btn btn-primary" @click="go('/bookings')">Go to my bookings <app-icon name="arrow-right"/></button><button class="btn btn-text" @click="go('/events')">Explore more events</button></div>

      <!-- WORKSPACE, BOOKINGS -->
      <div v-else-if="current==='bookings'" class="standard-page workspace-page"><div class="page-header"><div><span class="eyebrow">YOUR WORKSPACE</span><h1>{{t.customerDashboard}}<span class="heading-dot">.</span></h1><p>Every service, every detail, beautifully organized.</p></div><button class="btn btn-primary desktop-only" @click="go('/events')"><app-icon name="plus"/> New booking</button></div>
        <div v-if="!user" class="auth-guard"><span class="guard-icon"><app-icon name="shield"/></span><h2>Your event command center awaits.</h2><p>Sign in or choose a demo role to manage bookings and track your team.</p><button class="btn btn-primary" @click="loginOpen=true">{{t.signIn}} <app-icon name="arrow-right"/></button><button class="btn btn-secondary" @click="demoLogin('customer')">Explore customer demo</button></div>
        <template v-else><div class="metric-grid"><metric-card icon="bag" label="Total bookings" :value="dashboard?.totals?.bookings||0" color="lavender"/><metric-card icon="clock" label="Active requests" :value="dashboard?.totals?.active||0" color="orange"/><metric-card icon="image" label="Media assets" :value="dashboard?.totals?.media||0" color="teal"/><metric-card icon="chart" label="Booked value" :value="cash(dashboard?.totals?.bookedValueSAR||0)" color="pink"/></div>
        <div class="panel-card"><div class="panel-card-head"><div><h2>All bookings</h2><p>Manage dates, services and request status</p></div><button class="link-button" @click="refresh()"><app-icon name="clock"/> Refresh</button></div><div class="booking-list"><booking-row v-for="b in bookings" :key="b.id" :booking="b" :can-cancel="['pending','confirmed'].includes(b.status)&&['customer','exhibitor','admin'].includes(myRole)" @cancel="cancelBooking(b)"/></div><div v-if="!bookings.length" class="empty-inline"><app-icon name="bag"/><strong>No bookings yet</strong><button class="btn btn-secondary" @click="go('/events')">Find your first event</button></div></div>
        <div class="workspace-two-col"><div class="panel-card"><div class="panel-card-head"><h2>Media delivery</h2><button class="link-button" @click="go('/media')">Open library <app-icon name="arrow-right"/></button></div><div class="media-mini-preview" v-if="media.length"><img :src="mediaUrl(media[0])" alt="Delivered media preview" @error="imgErr"/><div><b>{{media.length}} asset{{media.length>1?'s':''}} in your workspace</b><p>Download and review approved deliverables</p></div></div><div class="empty-inline" v-else>Media will appear here when delivered.</div></div><div class="panel-card next-step"><div class="next-step-icon">✳</div><h2>Need another hand?</h2><p>Explore your next service or ask our concierge to help you plan.</p><button class="btn btn-secondary" @click="go('/concierge')">Ask concierge <app-icon name="arrow-right"/></button></div></div></template>
      </div>

      <!-- MEDIA LIBRARY -->
      <div v-else-if="current==='media'" class="standard-page"><div class="page-header"><div><span class="eyebrow">MEDIAOS / LIVE DELIVERY</span><h1>Every moment, delivered<span class="heading-dot">.</span></h1><p>{{t.gallery}}</p></div><button class="btn btn-primary" @click="openMediaUpload"><app-icon name="upload"/> {{t.upload}}</button></div>
        <div v-if="!user" class="auth-guard"><span class="guard-icon"><app-icon name="image"/></span><h2>Private, secure media delivery.</h2><p>Sign in to access assets belonging to your event bookings.</p><button class="btn btn-primary" @click="loginOpen=true">Sign in to media library <app-icon name="arrow-right"/></button></div>
        <template v-else><div class="media-toolbar"><span><app-icon name="shield"/> Role-aware private assets</span><span>{{media.length}} file{{media.length===1?'':'s'}} · Customer uploads require approval</span></div><div class="media-grid"><div class="media-card" v-for="m in media" :key="m.id"><div class="media-image"><img v-if="m.mime.startsWith('image/')" :src="mediaUrl(m)" :alt="m.title" @error="imgErr"/><div v-else class="pdf-preview"><app-icon name="file"/> PDF DOCUMENT</div><span class="media-badge">{{m.approved?'Approved':'Pending review'}}</span></div><div class="media-card-copy"><h3>{{m.title}}</h3><p>{{m.event_name}} · {{m.reference}}</p><div class="media-card-buttons"><a class="btn btn-secondary btn-sm" :href="mediaUrl(m)" target="_blank" rel="noopener"><app-icon name="external-link"/> Preview</a><a class="btn btn-primary btn-sm" :href="mediaUrl(m,true)"><app-icon name="download"/> Download</a></div><div class="approval-actions" v-if="['admin','organizer'].includes(myRole)"><button v-if="!m.approved" class="small-action" @click="setApproval(m,true)">✓ Approve</button><button v-else class="small-action" @click="setApproval(m,false)">Revoke approval</button></div></div></div></div>
          <div v-if="!media.length" class="empty-state media-empty"><div class="empty-orb"><app-icon name="image"/></div><h2>Your media hub is ready.</h2><p>Upload images or PDFs and keep event deliverables organized.</p><button class="btn btn-primary" @click="openMediaUpload">Upload first asset <app-icon name="arrow-right"/></button></div></template>
      </div>

      <!-- SUPPLIER PORTAL -->
      <div v-else-if="current==='supplier'" class="standard-page workspace-page"><div class="page-header"><div><span class="eyebrow">CREWOS · PARTNER PORTAL</span><h1>Good work, great teams<span class="heading-dot">.</span></h1><p>Manage availability, track assignments and deliver on time.</p></div><span class="workspace-pill"><app-icon name="shield"/> Supplier workspace</span></div><div v-if="myRole!=='supplier'" class="auth-guard"><h2>Switch to the supplier demo</h2><p>Explore supplier assignments, availability and delivery tools.</p><button class="btn btn-primary" @click="demoLogin('supplier')">Open supplier portal</button></div>
        <template v-else><div class="supplier-availability"><span class="availability-icon"><app-icon name="calendar"/></span><div><b>Accepting new assignments</b><p>Control whether your profile shows as available to organizers</p></div><button class="toggle" :class="{on:supplierAvailable}" :aria-pressed="supplierAvailable" @click="toggleAvailability"><i></i></button></div>
          <div class="metric-grid"><metric-card label="Assignments" :value="bookings.length" icon="briefcase" color="lavender"/><metric-card label="Pending" :value="bookings.filter(b=>b.status==='pending').length" icon="clock" color="orange"/><metric-card label="Completed" :value="bookings.filter(b=>b.status==='completed').length" icon="check" color="teal"/><metric-card label="Portfolio assets" :value="media.length" icon="image" color="pink"/></div>
          <div class="panel-card"><div class="panel-card-head"><div><h2>My assignments</h2><p>Changes are saved immediately to the demo database</p></div><button class="btn btn-secondary btn-sm" @click="go('/media')"><app-icon name="upload"/> Deliver media</button></div><div class="assignment-row" v-for="b in bookings" :key="b.id"><div class="assignment-left"><span class="assignment-id">{{b.reference}}</span><h3>{{b.service_title}}</h3><p>{{b.event_name}} · {{shortDate(b.service_date)}} at {{b.start_time}}</p><span class="status-pill" :class="bookingStatusColor(b.status)">{{b.status}}</span></div><div class="assignment-right"><small>Client: {{b.customer_name}}</small><b>{{cash(b.price_sar)}}</b><div class="assignment-actions"><button v-if="b.status==='pending'" class="btn btn-primary btn-sm" @click="updateBooking(b,'confirmed')">Accept</button><button v-if="b.status==='confirmed'" class="btn btn-primary btn-sm" @click="updateBooking(b,'completed')">Mark complete</button><button v-if="b.status==='pending'" class="btn btn-secondary btn-sm" @click="updateBooking(b,'rejected')">Decline</button></div></div></div><div v-if="!bookings.length" class="empty-inline">No assignments available for this supplier account.</div></div>
        </template>
      </div>

      <!-- ORGANIZER / ADMIN / EXHIBITOR -->
      <div v-else-if="['organizer','admin','exhibitor'].includes(current)" class="standard-page workspace-page"><div class="page-header"><div><span class="eyebrow">{{current==='admin'?'YAADIFYOS CONTROL CENTER':current==='organizer'?'EVENT OPERATIONS':'EXHIBITOR COMMAND CENTER'}}</span><h1>{{current==='admin'?'Super admin':current==='organizer'?'Organizer dashboard':'Exhibitor dashboard'}}<span class="heading-dot">.</span></h1><p>{{current==='exhibitor'?'Your team, service bookings and delivered content.':'A clearer view of everything happening across your events.'}}</p></div><span class="workspace-pill"><app-icon name="shield"/> {{current.toUpperCase()}} VIEW</span></div>
        <div v-if="myRole!==current && myRole!=='admin'" class="auth-guard"><h2>Explore the {{current}} workspace</h2><p>Switch to the appropriate demo role to access real role-based management tools.</p><button class="btn btn-primary" @click="demoLogin(current)">Open {{current}} demo</button></div>
        <template v-else><div class="metric-grid"><metric-card icon="bag" label="Bookings" :value="dashboard?.totals?.bookings||0" color="lavender"/><metric-card icon="clock" label="Active requests" :value="dashboard?.totals?.active||0" color="orange"/><metric-card icon="users" label="Partners" :value="dashboard?.totals?.suppliers||0" color="teal"/><metric-card icon="chart" label="Gross booked SAR" :value="(dashboard?.totals?.bookedValueSAR||0).toLocaleString('en')" color="pink"/></div>
          <div class="dashboard-tabs"><button :class="{active:dashTab==='overview'}" @click="dashTab='overview'">Overview</button><button :class="{active:dashTab==='bookings'}" @click="dashTab='bookings'">Bookings & approvals</button><button :class="{active:dashTab==='media'}" @click="dashTab='media'">Media review</button><button v-if="current!=='exhibitor'" :class="{active:dashTab==='partners'}" @click="dashTab='partners';requestSuppliers()">Suppliers</button></div>
          <div v-if="dashTab==='overview'" class="workspace-two-col"><div class="panel-card"><div class="panel-card-head"><h2>Latest requests</h2><button class="link-button" @click="dashTab='bookings'">See all <app-icon name="arrow-right"/></button></div><div class="compact-booking" v-for="b in bookings.slice(0,5)" :key="b.id"><span class="compact-dot"></span><div><b>{{b.service_title}}</b><small>{{b.event_name}} · {{shortDate(b.service_date)}}</small></div><span class="status-pill" :class="bookingStatusColor(b.status)">{{b.status}}</span></div><div v-if="!bookings.length" class="empty-inline">No active records.</div></div><div class="panel-card"><h2>Operations snapshot</h2><div class="ops-visual"><span v-for="(value,i) in [40,65,48,85,72,98,62,86,74,100]" :style="{'height':value+'%'}"></span></div><p class="muted">Illustrative chart visualization · Not live analytics</p><div class="ops-legend"><span><i class="legend-dot"></i> Booking activity</span><b>{{dashboard?.totals?.events||0}} demo events</b></div></div></div>
          <div v-else-if="dashTab==='bookings'" class="panel-card"><div class="panel-card-head"><h2>Bookings & requests</h2><span>{{bookings.length}} items</span></div><div class="admin-table-scroll"><table class="admin-table"><thead><tr><th>Booking</th><th>Client / event</th><th>When</th><th>Value</th><th>Status</th><th v-if="current!=='exhibitor'">Actions</th></tr></thead><tbody><tr v-for="b in bookings" :key="b.id"><td><b>{{b.reference}}</b><small>{{b.service_title}}</small></td><td>{{b.customer_name}}<small>{{b.event_name}}</small></td><td>{{shortDate(b.service_date)}}<small>{{b.start_time}}</small></td><td>{{cash(b.price_sar)}}</td><td><span class="status-pill" :class="bookingStatusColor(b.status)">{{b.status}}</span></td><td v-if="current!=='exhibitor'"><button v-if="b.status==='pending'" class="small-action" @click="updateBooking(b,'confirmed')">Confirm</button><button v-if="b.status==='confirmed'" class="small-action" @click="updateBooking(b,'completed')">Complete</button></td></tr></tbody></table><div v-if="!bookings.length" class="empty-inline">No bookings yet.</div></div></div>
          <div v-else-if="dashTab==='media'" class="panel-card"><div class="panel-card-head"><h2>Media approvals</h2><button class="btn btn-secondary btn-sm" @click="go('/media')">Open media hub</button></div><div class="review-row" v-for="m in media" :key="m.id"><span class="review-icon"><app-icon name="image"/></span><div><b>{{m.title}}</b><small>{{m.event_name}} · {{m.reference}}</small></div><span class="status-pill" :class="m.approved?'success':'warning'">{{m.approved?'Approved':'Pending'}}</span><button v-if="!m.approved && current!=='exhibitor'" class="btn btn-primary btn-sm" @click="setApproval(m,true)">Approve</button></div><div v-if="!media.length" class="empty-inline">No assets to review.</div></div>
          <div v-else-if="dashTab==='partners'" class="supplier-list-grid"><div class="supplier-card" v-for="s in suppliers" :key="s.id"><div class="supplier-avatar"><app-icon name="users"/></div><h3>{{s.company}}</h3><p>{{s.speciality}}</p><div class="supplier-card-meta"><span><app-icon name="map-pin"/>{{s.city}}</span><span><app-icon name="star"/> {{s.rating}}</span></div><span class="status-pill" :class="s.available?'success':'muted'">{{s.available?'Available':'Unavailable'}}</span></div></div>
        </template>
      </div>

      <!-- AI CONCIERGE -->
      <div v-else-if="current==='concierge'" class="concierge-page"><div class="chat-header"><div class="bot-orb">✳</div><div><span class="eyebrow">YAADIFYOS AI CONCIERGE</span><h1>Here for your big moments.</h1><p><span class="online-dot"></span> Interactive rules-based demo · Not a connected AI model</p></div></div>
        <div class="chat-suggestions"><button v-for="q in ['Book a videographer for GITEX','Find event crew in Riyadh','Plan a business dinner in Dubai','I need a creator for LEAP']" :key="q" @click="chatSend(q)"><app-icon name="sparkles"/>{{q}}</button></div>
        <div class="chat-window" ref="chatScroll"><div class="chat-message" v-for="(m,i) in chat" :key="i" :class="m.who"><span v-if="m.who==='assistant'" class="chat-avatar">✳</span><div class="bubble-wrap"><div class="bubble">{{m.text}}</div><div v-if="m.picks?.length" class="chat-picks"><button v-for="s in m.picks" :key="s.id" @click="bookService(s,m.event?.id)"><span><b>{{s.title}}</b><small>From {{cash(s.halfday_sar)}} / half-day</small></span><app-icon name="arrow-right"/></button></div></div></div><div v-if="chatBusy" class="chat-message assistant"><span class="chat-avatar">✳</span><div class="bubble typing"><i></i><i></i><i></i></div></div></div>
        <form class="chat-compose" @submit.prevent="chatSend()"><app-icon name="sparkles"/><input v-model="conciergeQuery" :placeholder="t.message" aria-label="Ask concierge"/><button type="submit" :disabled="!conciergeQuery.trim()||chatBusy" aria-label="Send message"><app-icon name="arrowup"/></button></form><p class="chat-disclaimer">The concierge suggests demo services only. No live inventory, AI processing or partner booking is connected.</p>
      </div>

      <!-- MODULE LANDINGS -->
      <div v-else-if="['city','crew','connect','creator'].includes(current)" class="module-page"><div class="module-cover" :class="current"><div class="module-cover-copy"><span class="eyebrow">YAADIFYOS / {{current==='crew'?'CREWOS':current==='city'?'CITYOS':current==='connect'?'CONNECTOS':'CREATOROS'}}</span><h1>{{current==='crew'?'Extraordinary events take extraordinary people.':current==='city'?'Your destination, taken care of.':current==='connect'?'Better connections. Better experiences.':'Content that feels like being there.'}}</h1><p>{{current==='crew'?'Find expert event crew and production support for every moment.':current==='city'?'Explore city support, venues and local experiences around your event.':current==='connect'?'Bring people together over experiences, meetings and memorable dinners.':'Meet creative talent, capture UGC and build event stories that travel.'}}</p><button class="btn btn-white" @click="go('/concierge')">Plan with concierge <app-icon name="arrow-right"/></button></div><div class="module-cover-symbol">✳</div></div>
        <template v-if="current==='city'"><div class="section-heading margin-top"><div><span class="eyebrow">CURATED CITY GUIDES</span><h2>Explore your event city</h2></div></div><div class="city-tabs"><button :class="{active:cityChoice==='Riyadh'}" @click="cityChoice='Riyadh'">Riyadh</button><button :class="{active:cityChoice==='Dubai'}" @click="cityChoice='Dubai'">Dubai</button></div><div class="city-feature"><img :src="img(cityChoice==='Riyadh'?'photo-1512453979798-5ea266f8880c':'photo-1518684079-3c830dcef090')" @error="imgErr" :alt="cityChoice"/><div><span class="eyebrow">{{cityChoice.toUpperCase()}} EVENT COMPANION</span><h2>Arrive ready for anything.</h2><p>Coordinate meeting rooms, dining, transport and concierge support with one booking request.</p><div class="city-highlights"><span><app-icon name="building"/> Meeting rooms</span><span><app-icon name="utensils"/> Business dining</span><span><app-icon name="map-pin"/> City concierge</span></div><button class="btn btn-primary" @click="go('/services?module=city')">Explore city services <app-icon name="arrow-right"/></button><small>Hotel inventory, tours, transport and restaurant APIs are planned, not live.</small></div></div></template>
        <div class="section-heading margin-top"><div><span class="eyebrow">SERVICES YOU CAN CONFIGURE</span><h2>{{current==='city'?'Travel better, meet better':current==='crew'?'The people behind the magic':current==='connect'?'Make room for connection':'Create the unexpected'}}</h2></div><button class="link-button" @click="go('/services?module='+(current==='creator'?'creator':current))">See all <app-icon name="arrow-right"/></button></div><div class="service-grid"><service-card v-for="s in services.filter(s=>s.module===(current==='creator'?'creator':current))" :key="s.id" :service="s" :currency="currency" :rate="rates[currency]" @open="serviceGo(s.id)" @book="bookService(s)"/></div><template v-if="current==='crew'"><div class="section-heading margin-top"><div><span class="eyebrow">VETTED PARTNER NETWORK</span><h2>Meet your production partners</h2><p class="section-explainer">Supplier profiles and availability are read directly from the demo database.</p></div></div><div class="supplier-list-grid"><div class="supplier-card" v-for="s in suppliers" :key="s.id"><div class="supplier-avatar"><app-icon name="users"/></div><h3>{{s.company}}</h3><p>{{s.bio}}</p><div class="supplier-card-meta"><span><app-icon name="map-pin"/>{{s.city}}</span><span><app-icon name="star"/> {{s.rating}}</span></div><span class="status-pill" :class="s.available?'success':'muted'">{{s.available?'Available':'Unavailable'}}</span></div></div></template><div class="roadmap-note"><app-icon name="sparkles"/><div><b>More in the pipeline</b><p>Live partner inventory, payments, matchmaking and UGC licensing are integration-phase features. The booking request flow above is functional.</p></div></div>
      </div>

      <!-- PROFILE -->
      <div v-else-if="current==='profile'" class="profile-page"><div class="page-header"><div><span class="eyebrow">ACCOUNT & PREFERENCES</span><h1>{{locale==='ar'?'مساحتي':'My space'}}<span class="heading-dot">.</span></h1><p>Make YaadifyOS yours.</p></div></div><div class="profile-grid"><div class="profile-main"><div class="profile-summary"><div class="profile-big-avatar">{{initials(user?.name||'Guest')}}</div><div><span class="eyebrow">{{user?.role?.toUpperCase()||'GUEST MODE'}}</span><h2>{{user?.name||'Hello, explorer!'}}</h2><p>{{user?.email||'Sign in for your personalized workspace.'}}</p><span v-if="user?.company" class="company-chip">{{user.company}}</span></div><button class="btn btn-secondary btn-sm" v-if="user" @click="logout"><app-icon name="log-out"/> Sign out</button><button class="btn btn-primary btn-sm" v-else @click="loginOpen=true">Sign in</button></div>
          <div class="profile-section"><h3>Appearance & language</h3><div class="setting-line"><span class="setting-icon"><app-icon :name="theme==='light'?'sun':'moon'"/></span><div><b>Color theme</b><small>Find your ideal viewing mode</small></div><div class="segmented"><button :class="{active:theme==='light'}" @click="setTheme('light')">Light</button><button :class="{active:theme==='dark'}" @click="setTheme('dark')">Dark</button></div></div><div class="setting-line"><span class="setting-icon"><app-icon name="globe"/></span><div><b>{{t.language}}</b><small>English and Arabic, with RTL support</small></div><div class="segmented"><button :class="{active:locale==='en'}" @click="setLocale('en')">EN</button><button :class="{active:locale==='ar'}" @click="setLocale('ar')">عربي</button></div></div><div class="setting-line"><span class="setting-icon"><app-icon name="credit"/></span><div><b>{{t.currency}}</b><small>Illustrative rates only, not live FX</small></div><select v-model="currency" @change="setCurrency(currency)" class="profile-select"><option>SAR</option><option>AED</option><option>USD</option></select></div><div class="setting-line"><span class="setting-icon"><app-icon name="bell"/></span><div><b>Local notifications</b><small>Demo browser notifications (not server push)</small></div><button class="btn btn-secondary btn-sm" @click="notify">{{notificationGranted?'Enabled':'Enable'}}</button></div></div>
          <div class="profile-section"><h3>Role workspaces</h3><div class="role-links"><button @click="go('/bookings')"><app-icon name="bag"/> Customer bookings <app-icon name="chevron-right"/></button><button @click="go('/exhibitor')"><app-icon name="building"/> Exhibitor dashboard <app-icon name="chevron-right"/></button><button @click="go('/supplier')"><app-icon name="users"/> Supplier portal <app-icon name="chevron-right"/></button><button @click="go('/organizer')"><app-icon name="calendar"/> Organizer dashboard <app-icon name="chevron-right"/></button><button @click="go('/admin')"><app-icon name="shield"/> Super admin <app-icon name="chevron-right"/></button></div></div>
        </div><aside class="profile-side"><div class="profile-demo-card"><span class="demo-label">DEMO PLAYGROUND</span><h3>Explore every perspective.</h3><p>Switch roles instantly to see what a full event operating system can do.</p><button v-for="role in ['customer','exhibitor','supplier','organizer','admin']" :key="role" @click="demoLogin(role)"><span class="role-emoji">{{role==='admin'?'✳':role==='supplier'?'⚡':role==='organizer'?'🎟':role==='exhibitor'?'🏢':'✨'}}</span><span>{{role[0].toUpperCase()+role.slice(1)}}</span><app-icon name="arrow-right"/></button></div><div class="about-card"><span class="mini-logo">✳</span><b>YaadifyOS · Version 0.1</b><p>Powered by Yaadify and Yaadgaar MediaTech</p><small>Standalone MVP · Demo data · Local database</small></div></aside></div></div>

      <!-- NOT FOUND FALLBACK -->
      <div v-else class="empty-state"><h2>Page not found</h2><button class="btn btn-primary" @click="go('/')">Back to home</button></div>

      </template>
    </main>
    <footer class="desktop-footer"><span>✳ YaadifyOS · Powered by Yaadify & Yaadgaar MediaTech</span><span>Standalone MVP · Illustrative demo content, not live inventory</span></footer>
  </div>
  <nav class="mobile-bottom-nav" aria-label="Mobile navigation">
    <button :class="{active:current==='home'}" @click="go('/')"><app-icon name="home"/><span>{{t.home}}</span></button>
    <button :class="{active:['events','event','services','service','book','crew','city','connect','creator'].includes(current)}" @click="go('/events')"><app-icon name="search"/><span>{{t.explore}}</span></button>
    <button :class="{active:['bookings','cart','success'].includes(current)}" @click="go('/bookings')"><span class="nav-badge" v-if="cart.length">{{cart.length}}</span><app-icon name="bag"/><span>{{t.bookings}}</span></button>
    <button :class="{active:current==='media'}" @click="go('/media')"><app-icon name="image"/><span>{{t.media}}</span></button>
    <button :class="{active:['profile','supplier','organizer','admin','exhibitor','concierge'].includes(current)}" @click="go('/profile')"><app-icon name="user"/><span>{{t.profile}}</span></button>
  </nav>
  <button v-if="!['concierge','book','success'].includes(current)" class="mobile-ai-fab" @click="go('/concierge')" aria-label="AI concierge"><app-icon name="sparkles"/></button>
  <div v-if="toast" class="toast-notice" :class="toastType"><app-icon :name="toastType==='error'?'bell':'check'"/>{{toast}}<button @click="toast=''" aria-label="Dismiss"><app-icon name="close"/></button></div>

  <!-- LOGIN BOTTOM SHEET / DESKTOP MODAL -->
  <div v-if="loginOpen" class="modal-overlay" @click.self="loginOpen=false"><div class="bottom-sheet login-sheet" role="dialog" aria-modal="true" aria-labelledby="login-title"><div class="sheet-handle"></div><button class="sheet-close" @click="loginOpen=false" aria-label="Close"><app-icon name="close"/></button><span class="sheet-brand">✳ yaadify<span>OS</span></span><h2 id="login-title">Welcome to your event workspace.</h2><p>Sign in or explore the platform using any demo role.</p><form @submit.prevent="login"><label>Email<input type="email" v-model="loginEmail" autocomplete="email" placeholder="you@company.com" required/></label><label>Password<input type="password" v-model="loginPassword" autocomplete="current-password" placeholder="Your password" required/></label><button class="btn btn-primary full-width" :disabled="loginBusy">{{loginBusy?'Signing in...':'Sign in'}} <app-icon name="arrow-right"/></button></form><div class="sheet-divider"><span>OR EXPLORE DEMO AS</span></div><div class="demo-role-grid"><button v-for="r in ['customer','exhibitor','supplier','organizer','admin']" :key="r" :disabled="loginBusy" @click="demoLogin(r)">{{r}}</button></div><p class="demo-credentials">Test login: customer@yaadifyos.demo / Demo123!</p></div></div>

  <!-- MEDIA UPLOAD SHEET -->
  <div v-if="mediaUploadOpen" class="modal-overlay" @click.self="mediaUploadOpen=false"><div class="bottom-sheet upload-sheet" role="dialog" aria-modal="true"><div class="sheet-handle"></div><button class="sheet-close" @click="mediaUploadOpen=false" aria-label="Close"><app-icon name="close"/></button><span class="eyebrow">MEDIA DELIVERY HUB</span><h2>Upload an event asset</h2><p>Attach a file to one of your bookings. Images and PDF under 6 MB are supported in this MVP.</p><form @submit.prevent="uploadMedia"><label>Booking<select v-model="uploadBookingId" required><option value="" disabled>Select booking</option><option v-for="b in bookings" :value="b.id">{{b.reference}} — {{b.event_name}}</option></select></label><label>Asset title<input v-model="uploadTitle" required maxlength="100" placeholder="Highlights · Day 1"/></label><label>File<input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" @change="handleFile" required/></label><div class="upload-help"><app-icon name="shield"/> Customer uploads stay pending until an organizer or admin approves.</div><button class="btn btn-primary full-width" type="submit" :disabled="uploadSending">{{uploadSending?'Uploading...':'Upload asset'}} <app-icon name="upload"/></button></form></div></div>
</div>`
});
app.component('app-icon',{props:{name:{type:String,default:'star'}},computed:{shape(){return ICONS[this.name]||ICONS.star;}},template:'<svg class="app-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" v-html="shape"></svg>'});
app.component('event-card',{props:['event','locale'],emits:['open'],methods:{img:PHOTO,shortDate(d){return formatDate(d,this.locale)},imgErr(e){e.target.src=imgFallback;}},template:`<button class="event-card" @click="$emit('open')"><div class="event-card-image"><img :src="img(event.image_key)" @error="imgErr" :alt="event.name" loading="lazy"/><span class="event-category">{{event.category}}</span><span class="event-image-arrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></span></div><div class="event-card-body"><div class="event-card-date">{{shortDate(event.starts_on)}} – {{shortDate(event.ends_on)}} · {{event.starts_on.slice(0,4)}}</div><h3>{{event.name}}</h3><div class="event-location"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0z"/><circle cx="12" cy="10" r="2.5"/></svg>{{event.city}}, {{event.country}}</div></div></button>`});
app.component('service-card',{props:['service','currency','rate'],emits:['open','book'],methods:{img:PHOTO,imgErr(e){e.target.src=imgFallback;},cash(v){return moneyCompact(Math.round((this.rate||1)*v),this.currency);}},template:`<div class="service-card"><button class="service-card-image" @click="$emit('open')"><img :src="img(service.image_key)" @error="imgErr" :alt="service.title" loading="lazy"/><span class="service-card-tag">{{service.category}}</span></button><div class="service-card-body"><span class="service-module">{{service.module.toUpperCase()}}OS <span>✦</span></span><button class="service-name" @click="$emit('open')">{{service.title}}</button><p>{{service.description}}</p><div class="service-bottom"><div class="service-price"><small>FROM</small><b>{{cash(service.hourly_sar)}}</b><span>/ hour</span></div><button class="service-book" @click="$emit('book')" aria-label="Configure booking"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14m-6-6 6 6-6 6"/></svg></button></div></div></div>`});
app.component('metric-card',{props:['label','value','icon','color'],template:`<div class="metric-card"><span :class="['metric-icon',color]"><app-icon :name="icon"/></span><div><span>{{label}}</span><strong>{{value}}</strong></div><span class="metric-corner">✳</span></div>`});
app.component('booking-row',{props:['booking','canCancel'],emits:['cancel'],methods:{shortDate(d){return formatDate(d);},money(v){return moneyCompact(v,'SAR');}},template:`<div class="booking-row"><div class="booking-row-image"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg></div><div class="booking-row-title"><strong>{{booking.service_title}}</strong><span>{{booking.event_name}} · {{booking.event_city}}</span><small>{{booking.reference}} · {{shortDate(booking.service_date)}} · {{booking.start_time}}</small></div><div class="booking-row-end"><span class="status-pill" :class="booking.status==='pending'?'warning':booking.status==='confirmed'||booking.status==='completed'?'success':'muted'">{{booking.status}}</span><b>{{money(booking.price_sar)}}</b><button v-if="canCancel" class="cancel-text" @click="$emit('cancel')">Cancel</button></div></div>`});
// Extra methods are attached after component initialization, but before mount.
app.mixin({methods:{requestSuppliers:async function(){if(!this.suppliers?.length){try{const data=await request('/api/suppliers');this.suppliers=data.suppliers;}catch(e){this.tip?.(e.message,'error');}}}}});
app.mount('#app');
})();
