const VERSION = 'yaadifyos-shell-v1';
const SHELL = ['/', '/index.html', '/styles.css', '/app.js', '/assets/vue.global.js', '/assets/icon.svg', '/assets/event-fallback.svg', '/assets/icon-192.png'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(VERSION).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(Promise.all([caches.keys().then(keys => Promise.all(keys.filter(key => key !== VERSION).map(key => caches.delete(key)))), self.clients.claim()]));
});
self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const u = new URL(req.url);
  if (u.origin !== self.location.origin || u.pathname.startsWith('/api/')) return;
  if (req.mode === 'navigate') {
    event.respondWith(fetch(req).catch(() => caches.match('/index.html'))); return;
  }
  event.respondWith(caches.match(req).then(cached => cached || fetch(req).then(response => {
    if (response.ok && /\.(js|css|png|svg|webmanifest)$/.test(u.pathname)) {
      const copy = response.clone(); caches.open(VERSION).then(cache => cache.put(req, copy));
    }
    return response;
  })));
});
// Real background push requires a configured push subscription and server VAPID integration.
self.addEventListener('push', event => {
  const payload = event.data?.json() || { title: 'YaadifyOS', body: 'You have an event update.' };
  event.waitUntil(self.registration.showNotification(payload.title || 'YaadifyOS', { body: payload.body || '', icon: '/assets/icon-192.png', data: { url: payload.url || '/bookings' } }));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(self.clients.openWindow(event.notification.data?.url || '/bookings'));
});
