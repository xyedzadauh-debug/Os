# Deploy YaadifyOS on Render's Free web service

This deployment is a **temporary public demo**, not a production service.

## Set up

1. Create a GitHub repository (private is fine if you connect its permissions on Render).
2. Upload all files in the `yaadifyos-mvp/` directory to the *root* of that repository, including `Dockerfile` and `render.yaml`. Do not upload the containing folder itself.
3. Sign into https://dashboard.render.com/ and connect GitHub.
4. Click **New > Web Service**, choose your repository, and use **Docker** runtime, **Free** instance, and **Frankfurt** region. (Alternatively use **New > Blueprint** to load `render.yaml`.)
5. If manually deploying, set environment variables `HOST=0.0.0.0`, `PORT=4173`, `DEMO_MODE=1`. No build command is required for Docker.
6. Choose **Deploy Web Service**. Once healthy, Render displays a public `https://...onrender.com` address; the URL cannot be predicted before deployment.
7. Verify the URL `/api/health` returns `{ "ok": true, ... }`, and test bookings and navigation.

## Very important limitations

- This app seeds publicly accessible **demo role accounts**, including demo admin. Never use the demo account system for real customers or sensitive data.
- On Render Free, the filesystem is **ephemeral**. SQLite records, uploaded files, logins, and edits can disappear on restart, redeploy or idle spin-down. The demo is intended for demonstration **only**; do not take real orders or upload private client files.
- No production payment processing, AI generation or real event/supplier availability is connected.
- The free instance sleeps after 15 minutes without traffic and can be slow to wake.
- For durable real-user operation, migrate to persistent Postgres/MySQL and object storage, remove demo login/admin access, and complete security review.

See `README.md` and `docs/openapi.yaml` for the application and API.
