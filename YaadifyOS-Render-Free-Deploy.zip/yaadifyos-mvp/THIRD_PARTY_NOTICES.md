# Third-party notices

- `public/assets/vue.global.js` is **Vue.js 3.5.13**, Copyright (c) 2018-present Yuxi (Evan You) and Vue contributors, made available under the **MIT License**. The full license is available at https://github.com/vuejs/core/blob/main/LICENSE.
- The sample image URLs point to `images.unsplash.com`. Images are not copied into this archive; review the applicable Unsplash license and image-specific rights before commercial distribution. The app includes an original SVG fallback for offline operation.
- YaadifyOS brand visuals, interface components and locally drawn icons are custom implementation assets in this MVP.
