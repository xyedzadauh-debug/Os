# Architecture and production integration brief

## Purpose

This release is a **working standalone product demonstrator**. It prioritizes usability, booking transactions, admin and supplier workflows, and real local storage, so YaadifyOS can be evaluated before adopting integrations and a larger infrastructure stack.

## Module boundaries

| Bounded context | Data today | Laravel service/controller target |
|---|---|---|
| Identity and access | users, sessions | Laravel Sanctum/Fortify, policies, password reset, MFA, role/tenant membership |
| Events | events | EventCatalogService, EventController, organizer tenant scoping |
| Services | services | ServiceCatalogService, supplier price books, dynamic availability |
| Bookings | bookings | ReservationService, availability holds, transaction coordinator |
| Supplier workforce | supplier_profiles, service assignment | SupplierService, payouts, crews and job calendar |
| Media | media + local uploads | MediaService, S3-compatible storage, signed URLs, transcoding queue |
| Operations | admin/organizer dashboards | MetricsService, finance/reconciliation, sponsor deliverable tracking |
| Concierge | simple rules | Verified tool-calling LLM gateway, RAG over inventory and policies |

Current DB relationships: users → sessions; users → supplier_profiles; events × services × users → bookings; bookings → media; audit_log for important writes.

## Migration to Laravel + MySQL

1. **Contracts first:** Keep public `/api/...` routes consistent with `docs/openapi.yaml`. Introduce `ApiClient` and Vue composables, then move views into Nuxt pages and app components as the frontend is upgraded. Do not rewrite the core experience first.
2. **Database:** Use `docs/mysql-schema.sql` as a starting reference, create Laravel migrations and Eloquent models, backfill the existing Yaadify user ID alongside the new YaadifyOS user/tenant ID, and provide UTC timestamps plus venue timezone identifiers. Apply zero-downtime migrations for production data.
3. **Identity:** Integrate with Yaadify authentication/SSO, replace demo roles with policies and scoped memberships (`organization_id`, `event_id`, `supplier_id`). Turn off demo login and remove seeded accounts.
4. **Inventory and checkout:** Add a dynamic supplier calendar, inventory locks/hold expiry, real 1/4/8-hour pricing rules, taxes and currency conversion, invoice preview and a payment-intent state machine. Add idempotency keys to all checkout writes, booking cancellation policy and webhooks with signature verification.
5. **Media pipeline:** Move files to private object storage, generate thumbnails/transcodes in background jobs, virus-scan uploads, implement least-privilege signed URLs, guest access tokens, organizer/sponsor libraries, delivery SLAs and content lifecycle/retention policies.
6. **External networks:** Integrate authorized event discovery feeds, hotel/restaurant/tour/transport marketplaces and supplier systems. Obtain content and commercial listing permissions; do not assume APIs or bookings are live.
7. **AI production:** Queue-based real clipping/transcription with consent and verified ML provider, moderation, human approvals, cost control, retriable jobs and relevant multilingual search.
8. **PWA platform:** Add Web Push VAPID subscription, notification preferences, event-triggered backend messages, offline outbox for uploads/booking actions, push delivery reporting, iOS/Android install guidance and accessibility checks.

## Security / operations before public deployment

- Remove demo users, role-switch endpoint and static passwords. Implement email verification, secure onboarding, password policy, MFA for elevated roles and rate limiting; log sensitive access events.
- Enforce organization-level scoping on every query (the MVP currently grants organizer/admin access to all seeded bookings). Add an organization model and policy matrix with integration tests for cross-tenant access denial.
- Use audited, separately stored backend secrets and central HTTPS identity/session architecture. Validate `Origin`/`Referer` and CSRF tokens and set secure cookies behind a TLS proxy.
- Set production-safe CORS, CSP, HSTS, upload scanning and content-type sniffing protection; move media to private S3-compatible storage, CDN thumbnails through authenticated gateways and signed URLs.
- Use immutable payment events, provider webhooks, authorized refund workflows and finance approvals; implement KSA VAT/ZATCA invoicing where applicable and country-specific tax handling.
- Model real times in UTC plus IANA timezone, support daylight-saving transitions, capacity by supplier not merely per service, supplier calendars, blackout intervals and working-hour rules.
- Add separate queue workers, database backups, SLO monitoring, structured logs, error reporting, audit retention, E2E browser tests, accessibility tests and load testing.
- Obtain commercial licenses for external visuals and verify event schedules, venue identities, third-party listings and supplier availability.

## Web PWA deployment

The current Node process listens on `127.0.0.1:4173` by default. For container hosting, set `HOST=0.0.0.0`. Put it behind a TLS-terminating reverse proxy and set `COOKIE_SECURE=1`. Host on the **same origin** for API and PWA unless CORS and credentials are intentionally rearchitected. Treat this configuration as a preview deployment only until the controls above are implemented.

## EventTech business model extensions

MediaOS: event media subscriptions, sponsor packages, express-edit add-ons, team allocation and private portals.
CrewOS: supplier take rate, recurring crew contracts, staff onboarding and job tracking.
CityOS: partner referral and booking income through licensed marketplace APIs.
ConnectOS: organizer-paid hosted networking and invite-only B2B dinners.
CreatorOS: creator campaigns, branded UGC collection, approvals and rights/licensing marketplace.

These are future commercial models, not activated billing features in this release.
