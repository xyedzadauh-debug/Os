-- YaadifyOS future MySQL 8 reference schema.
-- NOT used by the running standalone app; implement Laravel migrations and policies.
-- Add organization_id and event-specific role membership BEFORE multi-tenant deployment.
CREATE DATABASE IF NOT EXISTS yaadifyos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE yaadifyos;

CREATE TABLE users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  yaadify_user_id BIGINT UNSIGNED NULL,
  name VARCHAR(160) NOT NULL,
  email VARCHAR(254) NOT NULL UNIQUE,
  role ENUM('customer','exhibitor','supplier','organizer','admin') NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  company VARCHAR(180) NOT NULL DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_yaadify_user (yaadify_user_id)
);
CREATE TABLE sessions (
  token_hash CHAR(64) PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  expires_at BIGINT NOT NULL,
  CONSTRAINT fk_session_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(160) NOT NULL UNIQUE,
  name VARCHAR(255) NOT NULL,
  city VARCHAR(120) NOT NULL,
  country VARCHAR(120) NOT NULL,
  starts_on DATE NOT NULL,
  ends_on DATE NOT NULL,
  venue VARCHAR(255) NOT NULL,
  venue_timezone VARCHAR(80) NULL COMMENT 'Example: Asia/Riyadh',
  category VARCHAR(100) NOT NULL,
  description TEXT NOT NULL,
  image_key VARCHAR(200) NOT NULL,
  featured BOOLEAN DEFAULT FALSE,
  KEY idx_events_dates (starts_on, ends_on)
);
CREATE TABLE supplier_profiles (
  user_id BIGINT UNSIGNED PRIMARY KEY,
  speciality VARCHAR(255) NOT NULL,
  bio TEXT NOT NULL,
  city VARCHAR(120) NOT NULL,
  available BOOLEAN NOT NULL DEFAULT TRUE,
  rating DECIMAL(3,2) NOT NULL DEFAULT 4.90,
  CONSTRAINT fk_profile_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE services (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  module ENUM('media','crew','city','connect','creator') NOT NULL,
  category VARCHAR(160) NOT NULL,
  description TEXT NOT NULL,
  hourly_sar INT UNSIGNED NOT NULL,
  halfday_sar INT UNSIGNED NOT NULL,
  fullday_sar INT UNSIGNED NOT NULL,
  image_key VARCHAR(200) NOT NULL,
  inclusions TEXT NOT NULL,
  icon VARCHAR(50) NOT NULL,
  supplier_id BIGINT UNSIGNED NULL,
  CONSTRAINT fk_services_supplier FOREIGN KEY (supplier_id) REFERENCES users(id) ON DELETE SET NULL,
  KEY idx_service_module (module)
);
CREATE TABLE bookings (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference VARCHAR(30) NOT NULL UNIQUE,
  user_id BIGINT UNSIGNED NOT NULL,
  service_id BIGINT UNSIGNED NOT NULL,
  event_id BIGINT UNSIGNED NOT NULL,
  supplier_id BIGINT UNSIGNED NULL,
  service_date DATE NOT NULL,
  start_time TIME NOT NULL,
  duration ENUM('hour','half','full') NOT NULL,
  units SMALLINT UNSIGNED NOT NULL,
  price_sar INT UNSIGNED NOT NULL,
  currency ENUM('SAR','AED','USD') NOT NULL DEFAULT 'SAR',
  total_display DECIMAL(12,2) NOT NULL,
  status ENUM('pending','confirmed','completed','rejected','cancelled') NOT NULL DEFAULT 'pending',
  notes VARCHAR(400) NOT NULL DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_booking_customer FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_booking_service FOREIGN KEY (service_id) REFERENCES services(id),
  CONSTRAINT fk_booking_event FOREIGN KEY (event_id) REFERENCES events(id),
  CONSTRAINT fk_booking_supplier FOREIGN KEY (supplier_id) REFERENCES users(id) ON DELETE SET NULL,
  KEY idx_booking_owner (user_id, created_at),
  KEY idx_booking_supplier (supplier_id, service_date),
  KEY idx_booking_slot (service_id, event_id, service_date, start_time)
);
CREATE TABLE media (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  booking_id BIGINT UNSIGNED NOT NULL,
  uploader_id BIGINT UNSIGNED NULL,
  title VARCHAR(100) NOT NULL,
  file_name VARCHAR(120) NOT NULL,
  storage_name VARCHAR(255) NOT NULL,
  mime VARCHAR(80) NOT NULL,
  size BIGINT UNSIGNED NOT NULL,
  approved BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_media_booking FOREIGN KEY (booking_id) REFERENCES bookings(id),
  CONSTRAINT fk_media_uploader FOREIGN KEY (uploader_id) REFERENCES users(id) ON DELETE SET NULL,
  KEY idx_media_booking (booking_id)
);
CREATE TABLE audit_log (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  actor_id BIGINT UNSIGNED NULL,
  action VARCHAR(100) NOT NULL,
  entity_id VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_audit_actor (actor_id, created_at)
);
